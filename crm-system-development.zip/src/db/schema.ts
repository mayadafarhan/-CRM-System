import {
  date,
  integer,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const contactStatusEnum = pgEnum("contact_status", [
  "lead",
  "prospect",
  "customer",
  "churned",
]);

export const dealStageEnum = pgEnum("deal_stage", [
  "lead",
  "qualified",
  "proposal",
  "negotiation",
  "won",
  "lost",
]);

export const taskPriorityEnum = pgEnum("task_priority", [
  "low",
  "medium",
  "high",
]);

export const taskStatusEnum = pgEnum("task_status", [
  "todo",
  "in_progress",
  "done",
]);

export const activityTypeEnum = pgEnum("activity_type", [
  "note",
  "call",
  "email",
  "meeting",
]);

export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  industry: text("industry"),
  website: text("website"),
  phone: text("phone"),
  city: text("city"),
  employees: integer("employees"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  jobTitle: text("job_title"),
  companyId: integer("company_id").references(() => companies.id, {
    onDelete: "set null",
  }),
  status: contactStatusEnum("status").notNull().default("lead"),
  source: text("source"),
  city: text("city"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  lastContactedAt: timestamp("last_contacted_at", { withTimezone: true }),
});

export const deals = pgTable("deals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  companyId: integer("company_id").references(() => companies.id, {
    onDelete: "set null",
  }),
  contactId: integer("contact_id").references(() => contacts.id, {
    onDelete: "set null",
  }),
  stage: dealStageEnum("stage").notNull().default("lead"),
  value: numeric("value", { precision: 12, scale: 2 }).notNull().default("0"),
  currency: text("currency").notNull().default("EGP"),
  probability: integer("probability").notNull().default(20),
  owner: text("owner").notNull().default("فريق المبيعات"),
  source: text("source"),
  expectedCloseDate: date("expected_close_date"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  contactId: integer("contact_id").references(() => contacts.id, {
    onDelete: "set null",
  }),
  dealId: integer("deal_id").references(() => deals.id, {
    onDelete: "set null",
  }),
  assignee: text("assignee").notNull().default("أنت"),
  dueDate: date("due_date"),
  priority: taskPriorityEnum("priority").notNull().default("medium"),
  status: taskStatusEnum("status").notNull().default("todo"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: activityTypeEnum("type").notNull().default("note"),
  subject: text("subject").notNull(),
  body: text("body"),
  contactId: integer("contact_id").references(() => contacts.id, {
    onDelete: "cascade",
  }),
  dealId: integer("deal_id").references(() => deals.id, {
    onDelete: "set null",
  }),
  author: text("author").notNull().default("أنت"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Company = typeof companies.$inferSelect;
export type Contact = typeof contacts.$inferSelect;
export type Deal = typeof deals.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Activity = typeof activities.$inferSelect;

export type ContactStatus = Contact["status"];
export type DealStage = Deal["stage"];
export type TaskPriority = Task["priority"];
export type TaskStatus = Task["status"];
export type ActivityType = Activity["type"];
