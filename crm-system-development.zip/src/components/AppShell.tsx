"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Icon, Logo, type IconName } from "@/components/icons";
import { avatarColor, initials } from "@/lib/format";

const NAV: { href: string; label: string; icon: IconName; hint?: string }[] = [
  { href: "/", label: "لوحة التحكم", icon: "dashboard" },
  { href: "/contacts", label: "العملاء", icon: "users" },
  { href: "/companies", label: "الشركات", icon: "building" },
  { href: "/deals", label: "خط الصفقات", icon: "pipeline" },
  { href: "/tasks", label: "المهام", icon: "check" },
  { href: "/reports", label: "التقارير", icon: "chart" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [query, setQuery] = useState("");

  useEffect(() => {
    setMobileOpen(false);
  }, [pathname]);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  const onSearch = (event: FormEvent) => {
    event.preventDefault();
    const term = query.trim();
    const target = pathname.startsWith("/companies") ? "/companies" : "/contacts";
    router.push(term ? `${target}?search=${encodeURIComponent(term)}` : target);
  };

  const nav = (
    <nav className="flex flex-col gap-1">
      {NAV.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={`nav-link ${isActive(item.href) ? "nav-link-active" : ""}`}
        >
          <Icon
            name={item.icon}
            className={`h-[18px] w-[18px] ${isActive(item.href) ? "text-indigo-600" : "text-slate-400"}`}
          />
          <span>{item.label}</span>
          {isActive(item.href) && (
            <span className="mr-auto h-1.5 w-1.5 rounded-full bg-indigo-500" />
          )}
        </Link>
      ))}
    </nav>
  );

  const brand = (
    <Link href="/" className="flex items-center gap-3">
      <Logo size={40} />
      <span className="flex flex-col leading-tight">
        <span className="text-[17px] font-bold text-slate-900">مَدار CRM</span>
        <span className="text-[11px] text-slate-400">إدارة علاقات العملاء</span>
      </span>
    </Link>
  );

  const userCard = (
    <div className="flex items-center gap-3 rounded-2xl border border-slate-200/80 bg-slate-50/70 p-3">
      <span
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold text-white ${avatarColor("سارة منصور")}`}
      >
        {initials("سارة منصور")}
      </span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[13px] font-semibold text-slate-800">سارة منصور</p>
        <p className="truncate text-[11px] text-slate-400">مديرة المبيعات</p>
      </div>
      <Icon name="chevron" className="h-4 w-4 rotate-90 text-slate-400" />
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f6fb]">
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-[264px] flex-col border-l border-slate-200/80 bg-white px-4 py-5 lg:flex">
        <div className="px-2">{brand}</div>

        <Link href="/deals" className="btn-primary mt-6 w-full">
          <Icon name="plus" className="h-4 w-4" />
          صفقة جديدة
        </Link>

        <p className="mt-6 px-3 text-[10px] font-semibold uppercase tracking-widest text-slate-400">
          مساحة العمل
        </p>
        <div className="mt-2">{nav}</div>

        <div className="mt-6 rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50 to-violet-50 p-4">
          <div className="flex items-center gap-2 text-indigo-700">
            <Icon name="sparkle" className="h-4 w-4" />
            <p className="text-xs font-semibold">نصيحة اليوم</p>
          </div>
          <p className="mt-2 text-[12px] leading-6 text-slate-600">
            العملاء الذين تتابعهم خلال 24 ساعة من الاجتماع يزيد احتمال إتمام
            الصفقة بنسبة ٣ أضعاف.
          </p>
          <Link
            href="/tasks"
            className="mt-3 inline-flex items-center gap-1 text-[12px] font-semibold text-indigo-700 hover:underline"
          >
            راجع مهامك
            <Icon name="arrow" className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="mt-auto pt-5">{userCard}</div>
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="absolute inset-y-0 right-0 flex w-[280px] animate-fade flex-col gap-4 overflow-y-auto bg-white px-4 py-5 shadow-2xl">
            <div className="flex items-center justify-between">
              {brand}
              <button
                onClick={() => setMobileOpen(false)}
                className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                aria-label="إغلاق"
              >
                <Icon name="close" className="h-5 w-5" />
              </button>
            </div>
            <Link href="/deals" className="btn-primary w-full">
              <Icon name="plus" className="h-4 w-4" />
              صفقة جديدة
            </Link>
            {nav}
            <div className="mt-auto">{userCard}</div>
          </aside>
        </div>
      )}

      <div className="lg:pr-[264px]">
        <header className="sticky top-0 z-20 border-b border-slate-200/70 bg-[#f5f6fb]/85 backdrop-blur-lg">
          <div className="mx-auto flex h-16 max-w-[1440px] items-center gap-3 px-4 lg:px-8">
            <button
              onClick={() => setMobileOpen(true)}
              className="rounded-xl border border-slate-200 bg-white p-2 text-slate-600 lg:hidden"
              aria-label="القائمة"
            >
              <Icon name="menu" className="h-5 w-5" />
            </button>

            <form onSubmit={onSearch} className="relative flex-1 lg:max-w-md">
              <Icon
                name="search"
                className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              />
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="ابحث عن عميل، شركة، أو فرصة…"
                className="h-10 w-full rounded-xl border border-slate-200 bg-white pr-9 pl-3 text-[13px] outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-500/10"
              />
              <kbd className="absolute left-2.5 top-1/2 hidden -translate-y-1/2 rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[10px] text-slate-400 md:block">
                Enter
              </kbd>
            </form>

            <div className="mr-auto flex items-center gap-2">
              <Link
                href="/tasks"
                className="relative rounded-xl border border-slate-200 bg-white p-2.5 text-slate-500 transition hover:text-indigo-600"
                aria-label="المهام"
              >
                <Icon name="check" className="h-[18px] w-[18px]" />
              </Link>
              <Link
                href="/reports"
                className="rounded-xl border border-slate-200 bg-white p-2.5 text-slate-500 transition hover:text-indigo-600"
                aria-label="التقارير"
              >
                <Icon name="chart" className="h-[18px] w-[18px]" />
              </Link>
              <div className="hidden items-center gap-2 border-r border-slate-200 pr-3 sm:flex">
                <span
                  className={`flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold text-white ${avatarColor("سارة منصور")}`}
                >
                  {initials("سارة منصور")}
                </span>
                <div className="leading-tight">
                  <p className="text-[12px] font-semibold text-slate-800">سارة منصور</p>
                  <p className="text-[10px] text-slate-400">مديرة المبيعات</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-[1440px] px-4 py-6 lg:px-8 lg:py-8">
          {children}
        </main>
        <footer className="mx-auto max-w-[1440px] px-4 pb-8 text-[11px] text-slate-400 lg:px-8">
          مَدار CRM · نسخة تجريبية — بياناتك محفوظة في PostgreSQL
        </footer>
      </div>
    </div>
  );
}
