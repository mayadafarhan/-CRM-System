"use client";

import { useState, useTransition, type FormEvent, type ReactNode } from "react";
import {
  addActivity,
  createCompany,
  createContact,
  createDeal,
  createTask,
  setContactStatus,
  updateCompany,
  updateContact,
  updateDeal,
  updateTask,
} from "@/app/actions";
import { Icon, type IconName } from "@/components/icons";
import { Modal } from "@/components/Modal";
import {
  ACTIVITY_TYPES,
  CONTACT_STATUSES,
  CURRENCIES,
  DEAL_STAGES,
  PRIORITIES,
  SALES_SOURCES,
  TASK_STATUSES,
  TEAM,
  toDateInput,
} from "@/lib/format";
import type {
  ActivityType,
  Company,
  Contact,
  ContactStatus,
  Deal,
  DealStage,
  Task,
  TaskPriority,
  TaskStatus,
} from "@/db/schema";

export type CompanyOption = { id: number; name: string };
export type ContactOption = { id: number; name: string; companyId: number | null };
export type DealOption = { id: number; title: string };

export function TriggerButton({
  label,
  icon = "plus",
  className = "btn-primary",
  onClick,
}: {
  label: string;
  icon?: IconName;
  className?: string;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className={className}>
      <Icon name={icon} className="h-4 w-4" />
      {label}
    </button>
  );
}

function Field({
  label,
  children,
  className = "",
}: {
  label: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <span className="label">{label}</span>
      {children}
    </div>
  );
}

function Footer({
  pending,
  onCancel,
  error,
}: {
  pending: boolean;
  onCancel: () => void;
  error?: string | null;
}) {
  return (
    <div className="flex flex-col gap-2 border-t border-slate-100 px-5 py-4 sm:flex-row sm:items-center sm:justify-end">
      {error && (
        <p className="sm:ml-auto text-[12px] font-medium text-rose-600">{error}</p>
      )}
      <button type="button" className="btn-ghost" onClick={onCancel} disabled={pending}>
        إلغاء
      </button>
      <button type="submit" className="btn-primary" disabled={pending}>
        {pending ? "جارٍ الحفظ…" : "حفظ"}
      </button>
    </div>
  );
}

/* ---------------------------------- contact --------------------------------- */

export function ContactFormModal({
  companies,
  initial,
  triggerLabel,
  triggerClass = "btn-primary",
  triggerIcon = "plus",
}: {
  companies: CompanyOption[];
  initial?: Contact;
  triggerLabel: string;
  triggerClass?: string;
  triggerIcon?: IconName;
}) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const edit = Boolean(initial?.id);

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const fd = new FormData(event.currentTarget);
    setError(null);
    startTransition(async () => {
      try {
        if (edit) {
          fd.set("id", String(initial!.id));
          await updateContact(fd);
        } else {
          await createContact(fd);
        }
        setOpen(false);
      } catch {
        setError("تعذّر الحفظ، حاول مرة أخرى.");
      }
    });
  };

  return (
    <>
      <TriggerButton label={triggerLabel} icon={triggerIcon} className={triggerClass} onClick={() => setOpen(true)} />
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? `تعديل بيانات ${initial?.name}` : "إضافة عميل جديد"}
        description="البيانات الأساسية تظهر في بطاقة العميل ولوحة المؤشرات."
      >
        <form onSubmit={onSubmit}>
          <div className="grid gap-4 px-5 py-4 sm:grid-cols-2">
            <Field label="الاسم الكامل *">
              <input name="name" required defaultValue={initial?.name ?? ""} className="input" placeholder="مثال: هالة الشريف" />
            </Field>
            <Field label="المسمى الوظيفي">
              <input name="jobTitle" defaultValue={initial?.jobTitle ?? ""} className="input" placeholder="مديرة تقنية المعلومات" />
            </Field>
            <Field label="البريد الإلكتروني">
              <input name="email" type="email" dir="ltr" defaultValue={initial?.email ?? ""} className="input text-left" placeholder="name@company.com" />
            </Field>
            <Field label="رقم الهاتف">
              <input name="phone" dir="ltr" defaultValue={initial?.phone ?? ""} className="input text-left" placeholder="01001234567" />
            </Field>
            <Field label="الشركة">
              <select name="companyId" defaultValue={initial?.companyId ?? ""} className="input">
                <option value="">بدون شركة</option>
                {companies.map((company) => (
                  <option key={company.id} value={company.id}>
                    {company.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="الحالة">
              <select name="status" defaultValue={initial?.status ?? "lead"} className="input">
                {CONTACT_STATUSES.map((status) => (
                  <option key={status.key} value={status.key}>
                    {status.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="مصدر العميل">
              <select name="source" defaultValue={initial?.source ?? ""} className="input">
                <option value="">غير محدد</option>
                {SALES_SOURCES.map((source) => (
                  <option key={source} value={source}>
                    {source}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="المدينة">
              <input name="city" defaultValue={initial?.city ?? ""} className="input" placeholder="القاهرة" />
            </Field>
            <Field label="ملاحظات" className="sm:col-span-2">
              <textarea name="notes" defaultValue={initial?.notes ?? ""} className="textarea" placeholder="تفضيلات التواصل، القرارات، سياق مهم…" />
            </Field>
          </div>
          <Footer pending={pending} onCancel={() => setOpen(false)} error={error} />
        </form>
      </Modal>
    </>
  );
}

/* ---------------------------------- company --------------------------------- */

export function CompanyFormModal({
  initial,
  triggerLabel,
  triggerClass = "btn-primary",
  triggerIcon = "plus",
}: {
  initial?: Company;
  triggerLabel: string;
  triggerClass?: string;
  triggerIcon?: IconName;
}) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const edit = Boolean(initial?.id);

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const fd = new FormData(event.currentTarget);
    setError(null);
    startTransition(async () => {
      try {
        if (edit) {
          fd.set("id", String(initial!.id));
          await updateCompany(fd);
        } else {
          await createCompany(fd);
        }
        setOpen(false);
      } catch {
        setError("تعذّر الحفظ، حاول مرة أخرى.");
      }
    });
  };

  return (
    <>
      <TriggerButton label={triggerLabel} icon={triggerIcon} className={triggerClass} onClick={() => setOpen(true)} />
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? `تعديل ${initial?.name}` : "إضافة شركة"}
        description="اربط العملاء والصفقات بالشركة لمتابعة الحساب بالكامل."
      >
        <form onSubmit={onSubmit}>
          <div className="grid gap-4 px-5 py-4 sm:grid-cols-2">
            <Field label="اسم الشركة *" className="sm:col-span-2">
              <input name="name" required defaultValue={initial?.name ?? ""} className="input" placeholder="شركة النيل للتقنية" />
            </Field>
            <Field label="القطاع">
              <input name="industry" defaultValue={initial?.industry ?? ""} className="input" placeholder="حلول برمجية" />
            </Field>
            <Field label="الموقع الإلكتروني">
              <input name="website" dir="ltr" defaultValue={initial?.website ?? ""} className="input text-left" placeholder="company.com" />
            </Field>
            <Field label="الهاتف">
              <input name="phone" dir="ltr" defaultValue={initial?.phone ?? ""} className="input text-left" placeholder="0223456789" />
            </Field>
            <Field label="المدينة">
              <input name="city" defaultValue={initial?.city ?? ""} className="input" placeholder="القاهرة" />
            </Field>
            <Field label="عدد الموظفين">
              <input name="employees" type="number" min="0" defaultValue={initial?.employees ?? ""} className="input" placeholder="120" />
            </Field>
            <Field label="ملاحظات" className="sm:col-span-2">
              <textarea name="notes" defaultValue={initial?.notes ?? ""} className="textarea" placeholder="طبيعة الحساب، متطلبات خاصة…" />
            </Field>
          </div>
          <Footer pending={pending} onCancel={() => setOpen(false)} error={error} />
        </form>
      </Modal>
    </>
  );
}

/* ------------------------------------ deal ---------------------------------- */

export function DealFormModal({
  companies,
  contacts,
  initial,
  triggerLabel,
  triggerClass = "btn-primary",
  triggerIcon = "plus",
  defaultStage,
}: {
  companies: CompanyOption[];
  contacts: ContactOption[];
  initial?: Deal;
  triggerLabel: string;
  triggerClass?: string;
  triggerIcon?: IconName;
  defaultStage?: DealStage;
}) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const edit = Boolean(initial?.id);

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const fd = new FormData(event.currentTarget);
    setError(null);
    startTransition(async () => {
      try {
        if (edit) {
          fd.set("id", String(initial!.id));
          await updateDeal(fd);
        } else {
          await createDeal(fd);
        }
        setOpen(false);
      } catch {
        setError("تعذّر الحفظ، حاول مرة أخرى.");
      }
    });
  };

  return (
    <>
      <TriggerButton label={triggerLabel} icon={triggerIcon} className={triggerClass} onClick={() => setOpen(true)} />
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? "تعديل الصفقة" : "إضافة صفقة جديدة"}
        description="حدّد القيمة والمرحلة ليتحدّث خط الأنابيب تلقائياً."
        wide
      >
        <form onSubmit={onSubmit}>
          <div className="grid gap-4 px-5 py-4 sm:grid-cols-2">
            <Field label="عنوان الصفقة *" className="sm:col-span-2">
              <input name="title" required defaultValue={initial?.title ?? ""} className="input" placeholder="نظام إدارة المخازن — شركة…" />
            </Field>
            <Field label="الشركة">
              <select name="companyId" defaultValue={initial?.companyId ?? ""} className="input">
                <option value="">بدون شركة</option>
                {companies.map((company) => (
                  <option key={company.id} value={company.id}>
                    {company.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="جهة الاتصال">
              <select name="contactId" defaultValue={initial?.contactId ?? ""} className="input">
                <option value="">بدون جهة اتصال</option>
                {contacts.map((contact) => (
                  <option key={contact.id} value={contact.id}>
                    {contact.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="القيمة">
              <input name="value" type="number" min="0" step="1000" defaultValue={initial ? Number(initial.value) : ""} className="input" placeholder="250000" />
            </Field>
            <Field label="العملة">
              <select name="currency" defaultValue={initial?.currency ?? "EGP"} className="input">
                {CURRENCIES.map((currency) => (
                  <option key={currency} value={currency}>
                    {currency}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="المرحلة">
              <select name="stage" defaultValue={initial?.stage ?? defaultStage ?? "lead"} className="input">
                {DEAL_STAGES.map((stage) => (
                  <option key={stage.key} value={stage.key}>
                    {stage.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="احتمالية الإغلاق %">
              <input name="probability" type="number" min="0" max="100" step="5" defaultValue={initial?.probability ?? 20} className="input" />
            </Field>
            <Field label="المسؤول">
              <select name="owner" defaultValue={initial?.owner ?? TEAM[0]} className="input">
                {TEAM.map((member) => (
                  <option key={member} value={member}>
                    {member}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="المصدر">
              <select name="source" defaultValue={initial?.source ?? ""} className="input">
                <option value="">غير محدد</option>
                {SALES_SOURCES.map((source) => (
                  <option key={source} value={source}>
                    {source}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="تاريخ الإغلاق المتوقع">
              <input name="expectedCloseDate" type="date" defaultValue={toDateInput(initial?.expectedCloseDate)} className="input" />
            </Field>
            <Field label="ملاحظات" className="sm:col-span-2">
              <textarea name="notes" defaultValue={initial?.notes ?? ""} className="textarea" placeholder="تفاصيل العرض، شروط العميل…" />
            </Field>
          </div>
          <Footer pending={pending} onCancel={() => setOpen(false)} error={error} />
        </form>
      </Modal>
    </>
  );
}

/* ------------------------------------ task ---------------------------------- */

export function TaskFormModal({
  contacts,
  deals,
  initial,
  triggerLabel,
  triggerClass = "btn-primary",
  triggerIcon = "plus",
  defaultContactId,
}: {
  contacts: ContactOption[];
  deals: DealOption[];
  initial?: Task;
  triggerLabel: string;
  triggerClass?: string;
  triggerIcon?: IconName;
  defaultContactId?: number;
}) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const edit = Boolean(initial?.id);

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const fd = new FormData(event.currentTarget);
    setError(null);
    startTransition(async () => {
      try {
        if (edit) {
          fd.set("id", String(initial!.id));
          await updateTask(fd);
        } else {
          await createTask(fd);
        }
        setOpen(false);
      } catch {
        setError("تعذّر الحفظ، حاول مرة أخرى.");
      }
    });
  };

  return (
    <>
      <TriggerButton label={triggerLabel} icon={triggerIcon} className={triggerClass} onClick={() => setOpen(true)} />
      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={edit ? "تعديل المهمة" : "مهمة جديدة"}
        description="المهام المرتبطة بموعد تُظهر تنبيهات في لوحة التحكم."
      >
        <form onSubmit={onSubmit}>
          <div className="grid gap-4 px-5 py-4 sm:grid-cols-2">
            <Field label="عنوان المهمة *" className="sm:col-span-2">
              <input name="title" required defaultValue={initial?.title ?? ""} className="input" placeholder="متابعة عرض السعر مع…" />
            </Field>
            <Field label="جهة الاتصال">
              <select name="contactId" defaultValue={initial?.contactId ?? defaultContactId ?? ""} className="input">
                <option value="">غير مرتبطة</option>
                {contacts.map((contact) => (
                  <option key={contact.id} value={contact.id}>
                    {contact.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="الصفقة">
              <select name="dealId" defaultValue={initial?.dealId ?? ""} className="input">
                <option value="">غير مرتبطة</option>
                {deals.map((deal) => (
                  <option key={deal.id} value={deal.id}>
                    {deal.title}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="المسؤول">
              <select name="assignee" defaultValue={initial?.assignee ?? TEAM[0]} className="input">
                {[...TEAM, "أنت"].map((member) => (
                  <option key={member} value={member}>
                    {member}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="تاريخ الاستحقاق">
              <input name="dueDate" type="date" defaultValue={toDateInput(initial?.dueDate)} className="input" />
            </Field>
            <Field label="الأولوية">
              <select name="priority" defaultValue={initial?.priority ?? "medium"} className="input">
                {PRIORITIES.map((priority) => (
                  <option key={priority.key} value={priority.key}>
                    {priority.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="الحالة">
              <select name="status" defaultValue={initial?.status ?? "todo"} className="input">
                {TASK_STATUSES.map((status) => (
                  <option key={status.key} value={status.key}>
                    {status.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="تفاصيل" className="sm:col-span-2">
              <textarea name="description" defaultValue={initial?.description ?? ""} className="textarea" placeholder="خطوات التنفيذ…" />
            </Field>
          </div>
          <Footer pending={pending} onCancel={() => setOpen(false)} error={error} />
        </form>
      </Modal>
    </>
  );
}

/* --------------------------------- activity --------------------------------- */

export const ACTIVITY_TYPE_KEYS: ActivityType[] = ["note", "call", "email", "meeting"];

export function ActivityComposer({
  contactId,
  deals,
}: {
  contactId: number;
  deals: DealOption[];
}) {
  const [pending, startTransition] = useTransition();
  const [type, setType] = useState<ActivityType>("note");
  const [error, setError] = useState<string | null>(null);

  const onSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = event.currentTarget;
    const fd = new FormData(form);
    fd.set("contactId", String(contactId));
    fd.set("type", type);
    setError(null);
    startTransition(async () => {
      try {
        await addActivity(fd);
        form.reset();
      } catch {
        setError("تعذّر إضافة النشاط.");
      }
    });
  };

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {ACTIVITY_TYPES.map((item) => (
          <button
            key={item.key}
            type="button"
            onClick={() => setType(item.key)}
            className={`chip border transition ${
              type === item.key
                ? "border-indigo-300 bg-indigo-50 text-indigo-700"
                : "border-slate-200 bg-white text-slate-500 hover:bg-slate-50"
            }`}
          >
            <span>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </div>
      <input name="subject" required className="input" placeholder="عنوان النشاط…" />
      <textarea name="body" className="textarea min-h-[80px]" placeholder="ملاحظات الاجتماع أو ملخص المكالمة…" />
      <div className="grid gap-3 sm:grid-cols-2">
        <select name="dealId" className="input" defaultValue="">
          <option value="">بدون صفقة مرتبطة</option>
          {deals.map((deal) => (
            <option key={deal.id} value={deal.id}>
              {deal.title}
            </option>
          ))}
        </select>
        <select name="author" className="input" defaultValue={TEAM[0]}>
          {TEAM.map((member) => (
            <option key={member} value={member}>
              {member}
            </option>
          ))}
        </select>
      </div>
      {error && <p className="text-[12px] text-rose-600">{error}</p>}
      <button type="submit" className="btn-primary w-full" disabled={pending}>
        {pending ? "جارٍ الإضافة…" : "تسجيل النشاط"}
      </button>
    </form>
  );
}

export function ContactStatusControl({
  contactId,
  status,
}: {
  contactId: number;
  status: ContactStatus;
}) {
  const [pending, startTransition] = useTransition();
  return (
    <select
      defaultValue={status}
      disabled={pending}
      onChange={(event) => {
        const next = event.target.value as ContactStatus;
        startTransition(async () => {
          await setContactStatus(contactId, next);
        });
      }}
      className="input h-9 py-1 text-[13px]"
    >
      {CONTACT_STATUSES.map((item) => (
        <option key={item.key} value={item.key}>
          {item.label}
        </option>
      ))}
    </select>
  );
}

export type { TaskPriority, TaskStatus, ContactStatus };
