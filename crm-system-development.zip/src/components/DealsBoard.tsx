"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import { deleteDeal, moveDealStage } from "@/app/actions";
import { DealFormModal, type CompanyOption, type ContactOption } from "@/components/forms";
import { Icon } from "@/components/icons";
import { DeleteButton } from "@/components/Interactive";
import { Avatar, ProgressBar } from "@/components/ui";
import {
  DEAL_STAGES,
  formatCompactMoney,
  formatMoney,
  formatShortDate,
  daysUntil,
} from "@/lib/format";
import type { DealStage } from "@/db/schema";
import type { DealRow } from "@/lib/queries";

type Props = {
  deals: DealRow[];
  companies: CompanyOption[];
  contacts: ContactOption[];
};

export function DealsBoard({ deals, companies, contacts }: Props) {
  const router = useRouter();
  const [items, setItems] = useState(deals);
  const [dragId, setDragId] = useState<number | null>(null);
  const [overStage, setOverStage] = useState<DealStage | null>(null);
  const [, startTransition] = useTransition();
  const [view, setView] = useState<"board" | "list">("board");

  useEffect(() => {
    setItems(deals);
  }, [deals]);

  const move = (id: number, stage: DealStage) => {
    setItems((current) =>
      current.map((deal) =>
        deal.id === id
          ? {
              ...deal,
              stage,
              probability: stage === "won" ? 100 : stage === "lost" ? 0 : deal.probability,
            }
          : deal,
      ),
    );
    startTransition(async () => {
      await moveDealStage(id, stage);
      router.refresh();
    });
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="flex rounded-xl border border-slate-200 bg-white p-1">
            <button
              onClick={() => setView("board")}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium transition ${
                view === "board" ? "bg-slate-900 text-white" : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Icon name="grid" className="h-3.5 w-3.5" />
              لوحة
            </button>
            <button
              onClick={() => setView("list")}
              className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[12px] font-medium transition ${
                view === "list" ? "bg-slate-900 text-white" : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <Icon name="list" className="h-3.5 w-3.5" />
              قائمة
            </button>
          </div>
          <span className="text-[11px] text-slate-400">
            {items.length} صفقة · اسحب البطاقة لتغيير المرحلة
          </span>
        </div>
      </div>

      {view === "board" ? (
        <div className="-mx-4 overflow-x-auto px-4 pb-4 lg:mx-0 lg:px-0">
          <div className="flex min-w-max gap-3">
            {DEAL_STAGES.map((stage) => {
              const stageDeals = items.filter((deal) => deal.stage === stage.key);
              const total = stageDeals.reduce((sum, deal) => sum + Number(deal.value), 0);
              return (
                <div
                  key={stage.key}
                  onDragOver={(event) => {
                    event.preventDefault();
                    setOverStage(stage.key);
                  }}
                  onDragLeave={() => setOverStage(null)}
                  onDrop={(event) => {
                    event.preventDefault();
                    setOverStage(null);
                    if (dragId !== null) move(dragId, stage.key);
                    setDragId(null);
                  }}
                  className={`flex w-[278px] shrink-0 flex-col rounded-2xl border bg-slate-50/70 p-2.5 transition ${
                    overStage === stage.key
                      ? "border-indigo-400 bg-indigo-50/60"
                      : "border-slate-200/70"
                  }`}
                >
                  <div className="mb-2.5 flex items-center justify-between gap-2 px-1">
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${stage.dot}`} />
                      <p className="text-[12.5px] font-semibold text-slate-700">{stage.label}</p>
                      <span className="rounded-md bg-white px-1.5 py-0.5 text-[10px] font-semibold text-slate-500 ring-1 ring-slate-200">
                        {stageDeals.length}
                      </span>
                    </div>
                    <p className="text-[10.5px] font-medium text-slate-400">
                      {formatCompactMoney(total)}
                    </p>
                  </div>

                  <div className="flex flex-col gap-2">
                    {stageDeals.map((deal) => {
                      const days = daysUntil(deal.expectedCloseDate);
                      return (
                        <article
                          key={deal.id}
                          draggable
                          onDragStart={() => setDragId(deal.id)}
                          onDragEnd={() => setDragId(null)}
                          className={`group cursor-grab rounded-xl border border-slate-200/80 bg-white p-3 shadow-sm transition hover:-translate-y-0.5 hover:border-indigo-200 hover:shadow-md active:cursor-grabbing ${
                            dragId === deal.id ? "opacity-50" : ""
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <p className="line-clamp-2 text-[12.5px] font-semibold leading-5 text-slate-800">
                              {deal.title}
                            </p>
                            <div className="flex shrink-0 items-center gap-0.5">
                              <DealFormModal
                                companies={companies}
                                contacts={contacts}
                                initial={deal}
                                triggerLabel=""
                                triggerIcon="edit"
                                triggerClass="rounded-md p-1 text-slate-400 opacity-0 transition hover:bg-slate-100 hover:text-slate-700 group-hover:opacity-100"
                              />
                              <DeleteButton
                                id={deal.id}
                                action={deleteDeal}
                                confirmText="سيتم حذف الصفقة نهائياً. متابعة؟"
                                className="rounded-md p-1 text-slate-400 opacity-0 transition hover:bg-rose-50 hover:text-rose-600 group-hover:opacity-100"
                              />
                            </div>
                          </div>

                          <p className="mt-1 text-[11px] text-slate-400">
                            {deal.companyName ?? "بدون شركة"}
                          </p>

                          <div className="mt-2.5 flex items-baseline justify-between">
                            <p className="text-[14px] font-bold text-slate-900">
                              {formatMoney(deal.value, deal.currency)}
                            </p>
                            <span className={`chip ${stage.soft}`}>{deal.probability}%</span>
                          </div>

                          <div className="mt-2">
                            <ProgressBar
                              value={deal.probability}
                              height="h-1.5"
                              className={
                                stage.key === "won"
                                  ? "bg-emerald-500"
                                  : stage.key === "lost"
                                    ? "bg-rose-400"
                                    : "bg-indigo-500"
                              }
                            />
                          </div>

                          <div className="mt-2.5 flex items-center justify-between gap-2 border-t border-slate-100 pt-2">
                            <div className="flex items-center gap-1.5">
                              <Avatar name={deal.owner} size="sm" />
                              <span className="text-[10.5px] text-slate-500">{deal.owner}</span>
                            </div>
                            <span
                              className={`text-[10px] font-medium ${
                                days !== null && days < 0
                                  ? "text-rose-500"
                                  : "text-slate-400"
                              }`}
                            >
                              {deal.expectedCloseDate
                                ? formatShortDate(deal.expectedCloseDate)
                                : "بدون موعد"}
                            </span>
                          </div>
                        </article>
                      );
                    })}

                    {!stageDeals.length && (
                      <div className="rounded-xl border border-dashed border-slate-200 bg-white/60 px-3 py-6 text-center text-[11px] text-slate-400">
                        لا توجد صفقات هنا
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] border-collapse">
              <thead className="bg-slate-50/80">
                <tr>
                  <th className="th">الصفقة</th>
                  <th className="th">الشركة</th>
                  <th className="th">المرحلة</th>
                  <th className="th">القيمة</th>
                  <th className="th">الاحتمالية</th>
                  <th className="th">المسؤول</th>
                  <th className="th">الإغلاق</th>
                  <th className="th"></th>
                </tr>
              </thead>
              <tbody>
                {items.map((deal) => {
                  const stage = DEAL_STAGES.find((item) => item.key === deal.stage)!;
                  return (
                    <tr key={deal.id} className="border-t border-slate-100 hover:bg-slate-50/60">
                      <td className="td">
                        <p className="font-semibold text-slate-800">{deal.title}</p>
                        <p className="text-[11px] text-slate-400">{deal.contactName ?? "—"}</p>
                      </td>
                      <td className="td text-[12.5px]">{deal.companyName ?? "—"}</td>
                      <td className="td">
                        <span className={`chip ${stage.soft}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${stage.dot}`} />
                          {stage.label}
                        </span>
                      </td>
                      <td className="td font-semibold">{formatMoney(deal.value, deal.currency)}</td>
                      <td className="td">
                        <div className="flex items-center gap-2">
                          <ProgressBar value={deal.probability} height="h-1.5" className="w-16" />
                          <span className="text-[11px] text-slate-500">{deal.probability}%</span>
                        </div>
                      </td>
                      <td className="td">
                        <div className="flex items-center gap-1.5">
                          <Avatar name={deal.owner} size="sm" />
                          <span className="text-[12px]">{deal.owner}</span>
                        </div>
                      </td>
                      <td className="td text-[12px] text-slate-500">
                        {formatShortDate(deal.expectedCloseDate)}
                      </td>
                      <td className="td">
                        <div className="flex items-center gap-1">
                          <DealFormModal
                            companies={companies}
                            contacts={contacts}
                            initial={deal}
                            triggerLabel=""
                            triggerIcon="edit"
                            triggerClass="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                          />
                          <DeleteButton
                            id={deal.id}
                            action={deleteDeal}
                            className="rounded-md p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {!items.length && (
            <p className="px-4 py-10 text-center text-sm text-slate-500">
              لا توجد صفقات مطابقة للفلاتر الحالية.
            </p>
          )}
        </div>
      )}

      <p className="mt-4 text-center text-[11px] text-slate-400">
        إجمالي قيمة الصفقات المعروضة:{" "}
        <span className="font-semibold text-slate-600">
          {formatMoney(items.reduce((sum, deal) => sum + Number(deal.value), 0))}
        </span>{" "}
        ·{" "}
        <Link href="/reports" className="font-semibold text-indigo-600 hover:underline">
          تحليل الأداء
        </Link>
      </p>
    </div>
  );
}
