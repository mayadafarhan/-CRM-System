"use client";

import { useTransition } from "react";
import { toggleTask } from "@/app/actions";
import { Icon, type IconName } from "@/components/icons";

export function DeleteButton({
  id,
  action,
  label,
  confirmText = "هل أنت متأكد من الحذف؟ لا يمكن التراجع.",
  className = "inline-flex items-center gap-1.5 rounded-lg px-2 py-1.5 text-[12px] font-medium text-rose-600 transition hover:bg-rose-50",
  icon = "trash",
}: {
  id: number;
  action: (fd: FormData) => Promise<void>;
  label?: string;
  confirmText?: string;
  className?: string;
  icon?: IconName;
}) {
  const [pending, startTransition] = useTransition();

  return (
    <button
      type="button"
      disabled={pending}
      className={className}
      onClick={() => {
        if (!window.confirm(confirmText)) return;
        const fd = new FormData();
        fd.set("id", String(id));
        startTransition(async () => {
          await action(fd);
        });
      }}
    >
      <Icon name={icon} className="h-3.5 w-3.5" />
      {label && <span>{pending ? "جارٍ الحذف…" : label}</span>}
    </button>
  );
}

export function TaskCheckbox({
  id,
  done,
  label,
}: {
  id: number;
  done: boolean;
  label: string;
}) {
  const [pending, startTransition] = useTransition();

  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={done}
      aria-label={label}
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          await toggleTask(id);
        })
      }
      className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition ${
        done
          ? "border-emerald-500 bg-emerald-500 text-white"
          : "border-slate-300 bg-white text-transparent hover:border-indigo-400 hover:text-indigo-200"
      } ${pending ? "opacity-50" : ""}`}
    >
      <Icon name="check" className="h-3.5 w-3.5" />
    </button>
  );
}
