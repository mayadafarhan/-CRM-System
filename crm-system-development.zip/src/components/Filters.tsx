"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Icon } from "@/components/icons";

export type FilterSelect = {
  name: string;
  label: string;
  options: { value: string; label: string }[];
};

export function FilterBar({
  basePath,
  placeholder = "بحث…",
  searchValue = "",
  selects = [],
  values = {},
}: {
  basePath: string;
  placeholder?: string;
  searchValue?: string;
  selects?: FilterSelect[];
  values?: Record<string, string>;
}) {
  const router = useRouter();
  const [term, setTerm] = useState(searchValue);
  const initial = useRef(true);

  const buildUrl = (nextTerm: string, nextValues: Record<string, string>) => {
    const params = new URLSearchParams();
    if (nextTerm.trim()) params.set("search", nextTerm.trim());
    Object.entries(nextValues).forEach(([key, value]) => {
      if (value && value !== "all") params.set(key, value);
    });
    const query = params.toString();
    return query ? `${basePath}?${query}` : basePath;
  };

  useEffect(() => {
    if (initial.current) {
      initial.current = false;
      return;
    }
    const timer = setTimeout(() => {
      router.push(buildUrl(term, values));
    }, 400);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [term]);

  const active = term.trim() !== "" || Object.values(values).some((value) => value && value !== "all");

  return (
    <div className="mb-4 flex flex-wrap items-center gap-2">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          router.push(buildUrl(term, values));
        }}
        className="relative min-w-[220px] flex-1 sm:max-w-xs"
      >
        <Icon
          name="search"
          className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
        />
        <input
          value={term}
          onChange={(event) => setTerm(event.target.value)}
          placeholder={placeholder}
          className="h-10 w-full rounded-xl border border-slate-200 bg-white pr-9 pl-3 text-[13px] outline-none transition placeholder:text-slate-400 focus:border-indigo-300 focus:ring-4 focus:ring-indigo-500/10"
        />
      </form>

      {selects.map((select) => (
        <select
          key={select.name}
          value={values[select.name] ?? "all"}
          onChange={(event) =>
            router.push(buildUrl(term, { ...values, [select.name]: event.target.value }))
          }
          className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-[12.5px] text-slate-600 outline-none transition focus:border-indigo-300"
          aria-label={select.label}
        >
          <option value="all">{select.label}: الكل</option>
          {select.options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      ))}

      {active && (
        <button
          type="button"
          onClick={() => {
            setTerm("");
            router.push(basePath);
          }}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 text-[12px] font-medium text-slate-500 transition hover:bg-slate-50"
        >
          <Icon name="close" className="h-3.5 w-3.5" />
          تفريغ
        </button>
      )}
    </div>
  );
}
