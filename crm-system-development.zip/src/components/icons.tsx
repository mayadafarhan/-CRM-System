import type { SVGProps } from "react";

const paths: Record<string, string[]> = {
  dashboard: [
    "M4 13h6V4H4v9Zm0 7h6v-4H4v4Zm10 0h6v-9h-6v9Zm0-16v4h6V4h-6Z",
  ],
  users: [
    "M16 19v-1.5a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4V19",
    "M9 9.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z",
    "M22 19v-1.5a4 4 0 0 0-3-3.87",
    "M16 3.13a4 4 0 0 1 0 7.75",
  ],
  building: [
    "M4 21V6a2 2 0 0 1 2-2h7a2 2 0 0 1 2 2v15",
    "M15 10h3a2 2 0 0 1 2 2v9",
    "M2 21h20",
    "M8 8h3M8 12h3M8 16h3",
  ],
  pipeline: [
    "M3 4h18",
    "M6 4v5a3 3 0 0 0 3 3h6a3 3 0 0 1 3 3v5",
    "M18 4v5a3 3 0 0 1-3 3H9a3 3 0 0 0-3 3v5",
  ],
  check: [
    "M9 11.5 11.5 14 16 8.5",
    "M6 3h12a1 1 0 0 1 1 1v16.5l-3.5-2-3.5 2-3.5-2-3.5 2V4a1 1 0 0 1 1-1Z",
  ],
  chart: [
    "M4 20V10M10 20V4M16 20v-7M22 20H2",
  ],
  search: ["M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16Z", "m21 21-4.3-4.3"],
  plus: ["M12 5v14M5 12h14"],
  phone: [
    "M21 16.9v2.6a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 1.2 4a2 2 0 0 1 2-2.2h2.6a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L7 9.6a16 16 0 0 0 6 6l1.1-1.1a2 2 0 0 1 2.1-.4c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z",
  ],
  mail: [
    "M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z",
    "m3 7 9 6 9-6",
  ],
  calendar: [
    "M8 2v4M16 2v4",
    "M4 6h16a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Z",
    "M3 11h18",
  ],
  clock: ["M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z", "M12 7v5l3 2"],
  settings: [
    "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z",
    "M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z",
  ],
  menu: ["M4 6h16M4 12h16M4 18h16"],
  close: ["M18 6 6 18M6 6l12 12"],
  arrow: ["M19 12H5M11 18l-6-6 6-6"],
  sparkle: [
    "M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z",
    "M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z",
  ],
  trash: [
    "M3 6h18",
    "M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2",
    "M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6",
    "M10 11v6M14 11v6",
  ],
  edit: [
    "M12 20h9",
    "M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z",
  ],
  chevron: ["m9 18 6-6-6-6"],
  target: [
    "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z",
    "M12 18a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z",
    "M12 14a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
  ],
  money: [
    "M12 2v20",
    "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",
  ],
  note: [
    "M4 4h16v11l-5 5H4V4Z",
    "M20 15h-5v5",
    "M8 9h8M8 13h4",
  ],
  grid: [
    "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  ],
  list: ["M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"],
  whatsapp: [
    "M20.5 11.6a8.5 8.5 0 0 1-12.7 7.4L3 20.5l1.6-4.7a8.5 8.5 0 1 1 15.9-4.2Z",
    "M8.7 8.4c.3-.5.6-.5.9-.5h.6c.2 0 .4.1.6.5l.7 1.7c.1.2.1.4 0 .6l-.5.7c-.2.2-.2.4-.1.6.4.7 1 1.4 1.7 1.9.2.1.4.2.6 0l.7-.6c.2-.1.4-.2.6-.1l1.7.8c.3.1.4.3.4.5v.6c0 .5-.3 1-.7 1.2-.5.3-1.1.4-1.8.3a8 8 0 0 1-5.7-4.4c-.5-.9-.7-1.8-.5-2.6Z",
  ],
  external: ["M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", "M15 3h6v6M10 14 21 3"],
  flag: ["M4 21V4h12l-2 4 2 4H4"],
  layers: [
    "m12 2 9 5-9 5-9-5 9-5Z",
    "m3 12 9 5 9-5",
    "m3 17 9 5 9-5",
  ],
  logout: ["M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", "m16 17 5-5-5-5M21 12H9"],
};

export type IconName = keyof typeof paths;

export function Icon({
  name,
  className = "h-5 w-5",
  ...props
}: { name: IconName; className?: string } & SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      className={className}
      {...props}
    >
      {paths[name].map((d) => (
        <path key={d} d={d} />
      ))}
    </svg>
  );
}

export function Logo({ size = 40 }: { size?: number }) {
  return (
    <span
      className="relative inline-flex items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/25"
      style={{ width: size, height: size }}
    >
      <svg viewBox="0 0 24 24" fill="none" className="h-1/2 w-1/2">
        <path
          d="M12 3v18M3 12h18"
          stroke="white"
          strokeWidth="2.4"
          strokeLinecap="round"
        />
        <circle cx="12" cy="12" r="7.2" stroke="white" strokeWidth="1.6" opacity="0.55" />
      </svg>
    </span>
  );
}
