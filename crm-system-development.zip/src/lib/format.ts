import type {
  ActivityType,
  ContactStatus,
  DealStage,
  TaskPriority,
  TaskStatus,
} from "@/db/schema";

export const DEAL_STAGES: {
  key: DealStage;
  label: string;
  accent: string;
  dot: string;
  soft: string;
  ring: string;
}[] = [
  {
    key: "lead",
    label: "عميل محتمل",
    accent: "text-slate-600",
    dot: "bg-slate-400",
    soft: "bg-slate-100 text-slate-600",
    ring: "border-slate-300",
  },
  {
    key: "qualified",
    label: "مؤهل",
    accent: "text-sky-700",
    dot: "bg-sky-500",
    soft: "bg-sky-50 text-sky-700",
    ring: "border-sky-300",
  },
  {
    key: "proposal",
    label: "عرض سعر",
    accent: "text-violet-700",
    dot: "bg-violet-500",
    soft: "bg-violet-50 text-violet-700",
    ring: "border-violet-300",
  },
  {
    key: "negotiation",
    label: "تفاوض",
    accent: "text-amber-700",
    dot: "bg-amber-500",
    soft: "bg-amber-50 text-amber-700",
    ring: "border-amber-300",
  },
  {
    key: "won",
    label: "تم البيع",
    accent: "text-emerald-700",
    dot: "bg-emerald-500",
    soft: "bg-emerald-50 text-emerald-700",
    ring: "border-emerald-300",
  },
  {
    key: "lost",
    label: "خسارة",
    accent: "text-rose-700",
    dot: "bg-rose-500",
    soft: "bg-rose-50 text-rose-700",
    ring: "border-rose-300",
  },
];

export const OPEN_STAGES: DealStage[] = [
  "lead",
  "qualified",
  "proposal",
  "negotiation",
];

export const stageMeta = (stage: DealStage) =>
  DEAL_STAGES.find((item) => item.key === stage) ?? DEAL_STAGES[0];

export const CONTACT_STATUSES: {
  key: ContactStatus;
  label: string;
  soft: string;
  dot: string;
}[] = [
  {
    key: "lead",
    label: "عميل محتمل",
    soft: "bg-slate-100 text-slate-700",
    dot: "bg-slate-400",
  },
  {
    key: "prospect",
    label: "تحت التفاوض",
    soft: "bg-amber-50 text-amber-700",
    dot: "bg-amber-500",
  },
  {
    key: "customer",
    label: "عميل حالي",
    soft: "bg-emerald-50 text-emerald-700",
    dot: "bg-emerald-500",
  },
  {
    key: "churned",
    label: "عميل مفقود",
    soft: "bg-rose-50 text-rose-700",
    dot: "bg-rose-500",
  },
];

export const contactStatusMeta = (status: ContactStatus) =>
  CONTACT_STATUSES.find((item) => item.key === status) ?? CONTACT_STATUSES[0];

export const PRIORITIES: {
  key: TaskPriority;
  label: string;
  soft: string;
  dot: string;
}[] = [
  {
    key: "high",
    label: "عالية",
    soft: "bg-rose-50 text-rose-700 border-rose-200",
    dot: "bg-rose-500",
  },
  {
    key: "medium",
    label: "متوسطة",
    soft: "bg-amber-50 text-amber-700 border-amber-200",
    dot: "bg-amber-500",
  },
  {
    key: "low",
    label: "منخفضة",
    soft: "bg-slate-100 text-slate-600 border-slate-200",
    dot: "bg-slate-400",
  },
];

export const priorityMeta = (priority: TaskPriority) =>
  PRIORITIES.find((item) => item.key === priority) ?? PRIORITIES[1];

export const TASK_STATUSES: { key: TaskStatus; label: string }[] = [
  { key: "todo", label: "قائمة الانتظار" },
  { key: "in_progress", label: "قيد التنفيذ" },
  { key: "done", label: "مكتملة" },
];

export const taskStatusMeta = (status: TaskStatus) =>
  TASK_STATUSES.find((item) => item.key === status) ?? TASK_STATUSES[0];

export const ACTIVITY_TYPES: {
  key: ActivityType;
  label: string;
  icon: string;
  soft: string;
}[] = [
  {
    key: "note",
    label: "ملاحظة",
    icon: "📝",
    soft: "bg-slate-100 text-slate-700",
  },
  { key: "call", label: "مكالمة", icon: "📞", soft: "bg-sky-50 text-sky-700" },
  { key: "email", label: "بريد", icon: "✉️", soft: "bg-violet-50 text-violet-700" },
  { key: "meeting", label: "اجتماع", icon: "🤝", soft: "bg-emerald-50 text-emerald-700" },
];

export const activityTypeMeta = (type: ActivityType) =>
  ACTIVITY_TYPES.find((item) => item.key === type) ?? ACTIVITY_TYPES[0];

export const SALES_SOURCES = [
  "موقع إلكتروني",
  "إحالة عميل",
  "لينكدإن",
  "معرض تجاري",
  "مكالمة مباشرة",
  "حملة إعلانية",
  "واتساب",
];

export const CURRENCIES = ["EGP", "SAR", "AED", "USD"];

export const TEAM = ["سارة منصور", "أحمد فتحي", "نور الدين", "مريم عادل"];

export const currencyLabel = (code: string) => {
  switch (code) {
    case "SAR":
      return "ر.س";
    case "AED":
      return "د.إ";
    case "USD":
      return "$";
    default:
      return "ج.م";
  }
};

const LOCALE = "ar-EG-u-nu-latn";

const numberFormatter = new Intl.NumberFormat(LOCALE, {
  maximumFractionDigits: 0,
});

const compactNumberFormatter = new Intl.NumberFormat(LOCALE, {
  notation: "compact",
  maximumFractionDigits: 1,
});

export function formatMoney(value: number | string | null, currency = "EGP") {
  const amount = typeof value === "string" ? Number(value) : (value ?? 0);
  return `${numberFormatter.format(Math.round(amount))} ${currencyLabel(currency)}`;
}

export function formatNumber(value: number) {
  return numberFormatter.format(value);
}

export function formatCompactMoney(value: number, currency = "EGP") {
  return `${compactNumberFormatter.format(Math.round(value))} ${currencyLabel(currency)}`;
}

const dateFormatter = new Intl.DateTimeFormat(LOCALE, {
  day: "numeric",
  month: "long",
  year: "numeric",
});

const shortDateFormatter = new Intl.DateTimeFormat(LOCALE, {
  day: "numeric",
  month: "short",
});

export function formatDate(value: Date | string | null | undefined) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(`${value}T00:00:00`) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return dateFormatter.format(date);
}

export function formatShortDate(value: Date | string | null | undefined) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(`${value}T00:00:00`) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return shortDateFormatter.format(date);
}

export function formatDateTime(value: Date | string | null | undefined) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  return new Intl.DateTimeFormat(LOCALE, {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function toDateInput(value: Date | string | null | undefined) {
  if (!value) return "";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString().slice(0, 10);
}

export function relativeTime(value: Date | string | null | undefined) {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—";
  const diff = Date.now() - date.getTime();
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "الآن";
  if (minutes < 60) return `قبل ${formatNumber(minutes)} دقيقة`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `قبل ${formatNumber(hours)} ساعة`;
  const days = Math.round(hours / 24);
  if (days === 1) return "أمس";
  if (days < 30) return `قبل ${formatNumber(days)} يوم`;
  const months = Math.round(days / 30);
  if (months < 12) return `قبل ${formatNumber(months)} شهر`;
  return `قبل ${formatNumber(Math.round(months / 12))} سنة`;
}

export function initials(name: string) {
  const parts = name.trim().split(/\s+/);
  return parts.slice(0, 2).map((part) => part[0]).join("");
}

const AVATAR_COLORS = [
  "bg-indigo-500",
  "bg-emerald-500",
  "bg-amber-500",
  "bg-sky-500",
  "bg-rose-500",
  "bg-violet-500",
  "bg-teal-500",
  "bg-orange-500",
];

export function avatarColor(seed: string) {
  let hash = 0;
  for (let i = 0; i < seed.length; i += 1) {
    hash = (hash * 31 + seed.charCodeAt(i)) % 9973;
  }
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

export function daysUntil(value: string | null | undefined) {
  if (!value) return null;
  const target = new Date(`${value}T00:00:00`);
  if (Number.isNaN(target.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / 86400000);
}

export function dueLabel(value: string | null | undefined) {
  const days = daysUntil(value);
  if (days === null) return "بدون موعد";
  if (days < 0) return `متأخرة ${formatNumber(Math.abs(days))} يوم`;
  if (days === 0) return "اليوم";
  if (days === 1) return "غداً";
  return `بعد ${formatNumber(days)} يوم`;
}
