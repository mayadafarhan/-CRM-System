import {
  and,
  asc,
  desc,
  eq,
  ilike,
  inArray,
  ne,
  or,
  sql,
} from "drizzle-orm";
import { db } from "@/db";
import {
  activities,
  companies,
  contacts,
  deals,
  tasks,
  type ContactStatus,
  type DealStage,
} from "@/db/schema";
import { OPEN_STAGES } from "@/lib/format";

const openStagesSql = sql`${deals.stage} in ('lead','qualified','proposal','negotiation')`;

export type DealRow = Awaited<ReturnType<typeof getDeals>>[number];

export async function getDeals(filters?: {
  search?: string;
  stage?: DealStage;
  owner?: string;
  companyId?: number;
}) {
  const conditions = [];
  if (filters?.search) {
    conditions.push(
      or(
        ilike(deals.title, `%${filters.search}%`),
        ilike(companies.name, `%${filters.search}%`),
        ilike(contacts.name, `%${filters.search}%`),
      ),
    );
  }
  if (filters?.stage) conditions.push(eq(deals.stage, filters.stage));
  if (filters?.owner) conditions.push(eq(deals.owner, filters.owner));
  if (filters?.companyId) conditions.push(eq(deals.companyId, filters.companyId));

  return db
    .select({
      id: deals.id,
      title: deals.title,
      stage: deals.stage,
      value: deals.value,
      currency: deals.currency,
      probability: deals.probability,
      owner: deals.owner,
      source: deals.source,
      expectedCloseDate: deals.expectedCloseDate,
      notes: deals.notes,
      createdAt: deals.createdAt,
      updatedAt: deals.updatedAt,
      companyId: deals.companyId,
      contactId: deals.contactId,
      companyName: companies.name,
      contactName: contacts.name,
      contactPhone: contacts.phone,
    })
    .from(deals)
    .leftJoin(companies, eq(deals.companyId, companies.id))
    .leftJoin(contacts, eq(deals.contactId, contacts.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(deals.value));
}

export async function getTasks(filters?: {
  status?: "all" | "open" | "done" | "today" | "overdue";
  assignee?: string;
}) {
  const conditions = [];
  if (filters?.status === "open") conditions.push(ne(tasks.status, "done"));
  if (filters?.status === "done") conditions.push(eq(tasks.status, "done"));
  if (filters?.status === "today")
    conditions.push(
      and(ne(tasks.status, "done"), eq(tasks.dueDate, new Date().toISOString().slice(0, 10))),
    );
  if (filters?.status === "overdue")
    conditions.push(
      and(
        ne(tasks.status, "done"),
        sql`${tasks.dueDate} is not null and ${tasks.dueDate} < current_date`,
      ),
    );
  if (filters?.assignee) conditions.push(eq(tasks.assignee, filters.assignee));

  return db
    .select({
      id: tasks.id,
      title: tasks.title,
      description: tasks.description,
      assignee: tasks.assignee,
      dueDate: tasks.dueDate,
      priority: tasks.priority,
      status: tasks.status,
      completedAt: tasks.completedAt,
      createdAt: tasks.createdAt,
      contactId: tasks.contactId,
      dealId: tasks.dealId,
      contactName: contacts.name,
      dealTitle: deals.title,
    })
    .from(tasks)
    .leftJoin(contacts, eq(tasks.contactId, contacts.id))
    .leftJoin(deals, eq(tasks.dealId, deals.id))
    .orderBy(
      sql`case when ${tasks.status} = 'done' then 1 else 0 end`,
      sql`${tasks.dueDate} asc nulls last`,
      desc(tasks.priority),
    );
}

export async function getContacts(filters?: {
  search?: string;
  status?: ContactStatus;
  companyId?: number;
}) {
  const conditions = [];
  if (filters?.search) {
    conditions.push(
      or(
        ilike(contacts.name, `%${filters.search}%`),
        ilike(contacts.email, `%${filters.search}%`),
        ilike(contacts.phone, `%${filters.search}%`),
        ilike(contacts.jobTitle, `%${filters.search}%`),
        ilike(companies.name, `%${filters.search}%`),
      ),
    );
  }
  if (filters?.status) conditions.push(eq(contacts.status, filters.status));
  if (filters?.companyId) conditions.push(eq(contacts.companyId, filters.companyId));

  return db
    .select({
      id: contacts.id,
      name: contacts.name,
      email: contacts.email,
      phone: contacts.phone,
      jobTitle: contacts.jobTitle,
      status: contacts.status,
      source: contacts.source,
      city: contacts.city,
      notes: contacts.notes,
      lastContactedAt: contacts.lastContactedAt,
      createdAt: contacts.createdAt,
      companyId: contacts.companyId,
      companyName: companies.name,
    })
    .from(contacts)
    .leftJoin(companies, eq(contacts.companyId, companies.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(contacts.createdAt));
}

export async function getContactDetail(id: number) {
  const [contact] = await db
    .select({
      id: contacts.id,
      name: contacts.name,
      email: contacts.email,
      phone: contacts.phone,
      jobTitle: contacts.jobTitle,
      status: contacts.status,
      source: contacts.source,
      city: contacts.city,
      notes: contacts.notes,
      lastContactedAt: contacts.lastContactedAt,
      createdAt: contacts.createdAt,
      companyId: contacts.companyId,
      companyName: companies.name,
      companyIndustry: companies.industry,
      companyWebsite: companies.website,
      companyPhone: companies.phone,
      companyCity: companies.city,
    })
    .from(contacts)
    .leftJoin(companies, eq(contacts.companyId, companies.id))
    .where(eq(contacts.id, id))
    .limit(1);

  if (!contact) return null;

  const [contactDeals, contactTasks, contactActivities] = await Promise.all([
    db
      .select()
      .from(deals)
      .where(eq(deals.contactId, id))
      .orderBy(desc(deals.value)),
    db
      .select()
      .from(tasks)
      .where(eq(tasks.contactId, id))
      .orderBy(sql`${tasks.dueDate} asc nulls last`),
    db
      .select()
      .from(activities)
      .where(eq(activities.contactId, id))
      .orderBy(desc(activities.createdAt)),
  ]);

  return {
    contact,
    deals: contactDeals,
    tasks: contactTasks,
    activities: contactActivities,
  };
}

export async function getCompanies(filters?: { search?: string }) {
  const conditions = filters?.search
    ? or(
        ilike(companies.name, `%${filters.search}%`),
        ilike(companies.industry, `%${filters.search}%`),
        ilike(companies.city, `%${filters.search}%`),
      )
    : undefined;

  const rows = await db
    .select()
    .from(companies)
    .where(conditions)
    .orderBy(asc(companies.name));

  const [contactCounts, openDeals] = await Promise.all([
    db
      .select({
        companyId: contacts.companyId,
        count: sql<number>`count(*)::int`,
      })
      .from(contacts)
      .groupBy(contacts.companyId),
    db
      .select({
        companyId: deals.companyId,
        pipeline: sql<number>`coalesce(sum(${deals.value}), 0)::float`,
        openCount: sql<number>`count(*)::int`,
      })
      .from(deals)
      .where(openStagesSql)
      .groupBy(deals.companyId),
  ]);

  const contactMap = new Map(contactCounts.map((r) => [r.companyId, r.count]));
  const dealMap = new Map(openDeals.map((r) => [r.companyId, r]));

  return rows.map((company) => ({
    ...company,
    contactCount: contactMap.get(company.id) ?? 0,
    pipeline: dealMap.get(company.id)?.pipeline ?? 0,
    openDealCount: dealMap.get(company.id)?.openCount ?? 0,
  }));
}

export async function getOptions() {
  const [companyOptions, contactOptions, dealOptions] = await Promise.all([
    db
      .select({ id: companies.id, name: companies.name })
      .from(companies)
      .orderBy(asc(companies.name)),
    db
      .select({
        id: contacts.id,
        name: contacts.name,
        companyId: contacts.companyId,
      })
      .from(contacts)
      .orderBy(asc(contacts.name)),
    db
      .select({ id: deals.id, title: deals.title })
      .from(deals)
      .orderBy(desc(deals.createdAt)),
  ]);
  return { companies: companyOptions, contacts: contactOptions, deals: dealOptions };
}

export async function getDashboard() {
  const today = new Date().toISOString().slice(0, 10);
  const monthStart = new Date();
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);

  const [allDeals, allContacts, openTasks, recentActivities, statusCounts] =
    await Promise.all([
      db
        .select({
          id: deals.id,
          stage: deals.stage,
          value: deals.value,
          probability: deals.probability,
          owner: deals.owner,
          source: deals.source,
          expectedCloseDate: deals.expectedCloseDate,
          createdAt: deals.createdAt,
          title: deals.title,
          companyName: companies.name,
          contactName: contacts.name,
        })
        .from(deals)
        .leftJoin(companies, eq(deals.companyId, companies.id))
        .leftJoin(contacts, eq(deals.contactId, contacts.id))
        .orderBy(desc(deals.value)),
      db
        .select({
          id: contacts.id,
          name: contacts.name,
          status: contacts.status,
          companyName: companies.name,
          createdAt: contacts.createdAt,
        })
        .from(contacts)
        .leftJoin(companies, eq(contacts.companyId, companies.id))
        .orderBy(desc(contacts.createdAt)),
      db
        .select({
          id: tasks.id,
          title: tasks.title,
          dueDate: tasks.dueDate,
          priority: tasks.priority,
          status: tasks.status,
          assignee: tasks.assignee,
          contactId: tasks.contactId,
          contactName: contacts.name,
        })
        .from(tasks)
        .leftJoin(contacts, eq(tasks.contactId, contacts.id))
        .where(ne(tasks.status, "done"))
        .orderBy(sql`${tasks.dueDate} asc nulls last`)
        .limit(6),
      db
        .select({
          id: activities.id,
          type: activities.type,
          subject: activities.subject,
          body: activities.body,
          author: activities.author,
          createdAt: activities.createdAt,
          contactId: activities.contactId,
          contactName: contacts.name,
          dealTitle: deals.title,
        })
        .from(activities)
        .leftJoin(contacts, eq(activities.contactId, contacts.id))
        .leftJoin(deals, eq(activities.dealId, deals.id))
        .orderBy(desc(activities.createdAt))
        .limit(6),
      db
        .select({
          status: contacts.status,
          count: sql<number>`count(*)::int`,
        })
        .from(contacts)
        .groupBy(contacts.status),
    ]);

  const openDeals = allDeals.filter((deal) =>
    OPEN_STAGES.includes(deal.stage as DealStage),
  );
  const wonDeals = allDeals.filter((deal) => deal.stage === "won");
  const lostDeals = allDeals.filter((deal) => deal.stage === "lost");

  const pipelineValue = openDeals.reduce(
    (sum, deal) => sum + Number(deal.value),
    0,
  );
  const weightedValue = openDeals.reduce(
    (sum, deal) => sum + (Number(deal.value) * deal.probability) / 100,
    0,
  );
  const wonValue = wonDeals.reduce((sum, deal) => sum + Number(deal.value), 0);
  const closedCount = wonDeals.length + lostDeals.length;
  const winRate = closedCount ? Math.round((wonDeals.length / closedCount) * 100) : 0;
  const avgDeal = wonDeals.length ? wonValue / wonDeals.length : 0;

  const wonThisMonth = wonDeals.reduce((sum, deal) => {
    const created = deal.createdAt ? new Date(deal.createdAt) : new Date(0);
    return created >= monthStart ? sum + Number(deal.value) : sum;
  }, 0);

  const stageTotals = (
    ["lead", "qualified", "proposal", "negotiation", "won", "lost"] as DealStage[]
  ).map((stage) => {
    const items = allDeals.filter((deal) => deal.stage === stage);
    return {
      stage,
      count: items.length,
      value: items.reduce((sum, deal) => sum + Number(deal.value), 0),
    };
  });

  const monthly = Array.from({ length: 6 }).map((_, index) => {
    const date = new Date();
    date.setMonth(date.getMonth() - (5 - index));
    const key = `${date.getFullYear()}-${date.getMonth()}`;
    const label = new Intl.DateTimeFormat("ar-EG", { month: "short" }).format(date);
    const monthDeals = allDeals.filter((deal) => {
      if (!deal.createdAt) return false;
      const created = new Date(deal.createdAt);
      return `${created.getFullYear()}-${created.getMonth()}` === key;
    });
    return {
      label,
      won: monthDeals
        .filter((deal) => deal.stage === "won")
        .reduce((sum, deal) => sum + Number(deal.value), 0),
      created: monthDeals.length,
    };
  });

  const statusMap = new Map(statusCounts.map((row) => [row.status, row.count]));

  return {
    metrics: {
      contacts: allContacts.length,
      customers: statusMap.get("customer") ?? 0,
      openDeals: openDeals.length,
      pipelineValue,
      weightedValue,
      wonValue,
      wonThisMonth,
      winRate,
      avgDeal,
      openTasksCount: openTasks.length,
      overdueTasks: openTasks.filter(
        (task) => task.dueDate && task.dueDate < today,
      ).length,
      newContacts: allContacts.filter((contact) =>
        contact.createdAt ? new Date(contact.createdAt) >= monthStart : false,
      ).length,
    },
    statusMap: Object.fromEntries(statusMap) as Record<string, number>,
    topDeals: openDeals.slice(0, 5),
    recentActivities,
    upcomingTasks: openTasks,
    stageTotals,
    monthly,
    latestContacts: allContacts.slice(0, 4),
  };
}

export async function getReports() {
  const [allDeals, owners, sources, allContacts] = await Promise.all([
    db
      .select({
        stage: deals.stage,
        value: deals.value,
        source: deals.source,
        owner: deals.owner,
        createdAt: deals.createdAt,
      })
      .from(deals),
    db
      .select({
        owner: deals.owner,
        count: sql<number>`count(*)::int`,
        total: sql<number>`coalesce(sum(${deals.value}), 0)::float`,
        won: sql<number>`coalesce(sum(case when ${deals.stage} = 'won' then ${deals.value} else 0 end), 0)::float`,
        wonCount: sql<number>`count(*) filter (where ${deals.stage} = 'won')::int`,
      })
      .from(deals)
      .groupBy(deals.owner)
      .orderBy(desc(sql`coalesce(sum(${deals.value}), 0)`)),
    db
      .select({
        source: deals.source,
        count: sql<number>`count(*)::int`,
        total: sql<number>`coalesce(sum(${deals.value}), 0)::float`,
      })
      .from(deals)
      .groupBy(deals.source)
      .orderBy(desc(sql`coalesce(sum(${deals.value}), 0)`)),
    db
      .select({ status: contacts.status, count: sql<number>`count(*)::int` })
      .from(contacts)
      .groupBy(contacts.status),
  ]);

  const stageTotals = (
    ["lead", "qualified", "proposal", "negotiation", "won", "lost"] as DealStage[]
  ).map((stage) => {
    const items = allDeals.filter((deal) => deal.stage === stage);
    return {
      stage,
      count: items.length,
      value: items.reduce((sum, deal) => sum + Number(deal.value), 0),
    };
  });

  const monthly = Array.from({ length: 8 }).map((_, index) => {
    const date = new Date();
    date.setMonth(date.getMonth() - (7 - index));
    const label = new Intl.DateTimeFormat("ar-EG", { month: "short" }).format(date);
    const key = `${date.getFullYear()}-${date.getMonth()}`;
    const monthDeals = allDeals.filter((deal) => {
      if (!deal.createdAt) return false;
      const created = new Date(deal.createdAt);
      return `${created.getFullYear()}-${created.getMonth()}` === key;
    });
    return {
      label,
      value: monthDeals.reduce((sum, deal) => sum + Number(deal.value), 0),
      count: monthDeals.length,
    };
  });

  return {
    stageTotals,
    owners,
    sources,
    monthly,
    contactsByStatus: allContacts,
    totalDeals: allDeals.length,
  };
}

export async function getOpenDealCountForContactIds(ids: number[]) {
  if (!ids.length) return new Map<number, number>();
  const rows = await db
    .select({
      contactId: deals.contactId,
      count: sql<number>`count(*)::int`,
    })
    .from(deals)
    .where(and(inArray(deals.contactId, ids), openStagesSql))
    .groupBy(deals.contactId);
  return new Map(rows.map((row) => [row.contactId ?? 0, row.count]));
}
