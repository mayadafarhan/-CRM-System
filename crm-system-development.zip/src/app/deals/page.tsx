import { DealsBoard } from "@/components/DealsBoard";
import { FilterBar } from "@/components/Filters";
import { DealFormModal } from "@/components/forms";
import { PageHeader } from "@/components/ui";
import {
  DEAL_STAGES,
  formatCompactMoney,
  formatNumber,
  OPEN_STAGES,
  TEAM,
} from "@/lib/format";
import { getDeals, getOptions } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";
import type { DealStage } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function DealsPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string; stage?: string; owner?: string }>;
}) {
  await ensureSeed();
  const params = await searchParams;
  const stage = DEAL_STAGES.find((item) => item.key === params.stage)?.key;

  const [allDeals, deals, options] = await Promise.all([
    getDeals(),
    getDeals({
      search: params.search,
      stage: stage as DealStage | undefined,
      owner: params.owner,
    }),
    getOptions(),
  ]);

  const openDeals = allDeals.filter((deal) => OPEN_STAGES.includes(deal.stage));
  const wonDeals = allDeals.filter((deal) => deal.stage === "won");
  const pipeline = openDeals.reduce((sum, deal) => sum + Number(deal.value), 0);
  const weighted = openDeals.reduce(
    (sum, deal) => sum + (Number(deal.value) * deal.probability) / 100,
    0,
  );
  const won = wonDeals.reduce((sum, deal) => sum + Number(deal.value), 0);
  const lostCount = allDeals.filter((deal) => deal.stage === "lost").length;
  const winRate =
    wonDeals.length + lostCount > 0
      ? Math.round((wonDeals.length / (wonDeals.length + lostCount)) * 100)
      : 0;

  return (
    <div>
      <PageHeader
        title="خط الصفقات"
        description="تابع كل الفرص من أول تواصل حتى الإغلاق — اسحب البطاقة لتحديث المرحلة."
      >
        <DealFormModal
          companies={options.companies}
          contacts={options.contacts}
          triggerLabel="صفقة جديدة"
        />
      </PageHeader>

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">قيمة خط الأنابيب</p>
          <p className="mt-1 text-xl font-bold text-slate-900">{formatCompactMoney(pipeline)}</p>
          <p className="text-[10.5px] text-slate-400">{formatNumber(openDeals.length)} صفقة مفتوحة</p>
        </div>
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">القيمة المرجّحة</p>
          <p className="mt-1 text-xl font-bold text-indigo-700">{formatCompactMoney(weighted)}</p>
          <p className="text-[10.5px] text-slate-400">حسب احتمالية الإغلاق</p>
        </div>
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">صفقات مكسوبة</p>
          <p className="mt-1 text-xl font-bold text-emerald-700">{formatCompactMoney(won)}</p>
          <p className="text-[10.5px] text-slate-400">{formatNumber(wonDeals.length)} صفقة</p>
        </div>
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">نسبة الإغلاق</p>
          <p className="mt-1 text-xl font-bold text-slate-900">{formatNumber(winRate)}%</p>
          <p className="text-[10.5px] text-slate-400">{formatNumber(lostCount)} صفقة خاسرة</p>
        </div>
      </div>

      <FilterBar
        basePath="/deals"
        placeholder="ابحث عن صفقة أو شركة…"
        searchValue={params.search ?? ""}
        values={{ stage: params.stage ?? "all", owner: params.owner ?? "all" }}
        selects={[
          {
            name: "stage",
            label: "المرحلة",
            options: DEAL_STAGES.map((item) => ({ value: item.key, label: item.label })),
          },
          {
            name: "owner",
            label: "المسؤول",
            options: TEAM.map((member) => ({ value: member, label: member })),
          },
        ]}
      />

      <DealsBoard deals={deals} companies={options.companies} contacts={options.contacts} />
    </div>
  );
}
