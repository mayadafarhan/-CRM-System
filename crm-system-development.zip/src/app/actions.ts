"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db } from "@/db";
import {
  activities,
  companies,
  contacts,
  deals,
  tasks,
  type ActivityType,
  type ContactStatus,
  type DealStage,
  type TaskPriority,
  type TaskStatus,
} from "@/db/schema";

function text(fd: FormData, key: string) {
  const value = fd.get(key);
  return typeof value === "string" ? value.trim() : "";
}

function nullable(fd: FormData, key: string) {
  const value = text(fd, key);
  return value.length ? value : null;
}

function numberField(fd: FormData, key: string, fallback = 0) {
  const value = Number(text(fd, key).replace(/,/g, ""));
  return Number.isFinite(value) ? value : fallback;
}

function optionalId(fd: FormData, key: string) {
  const value = Number(text(fd, key));
  return Number.isFinite(value) && value > 0 ? value : null;
}

function refresh() {
  revalidatePath("/", "layout");
}

/* ---------------------------------- contacts --------------------------------- */

export async function createContact(fd: FormData) {
  const name = text(fd, "name");
  if (!name) return;
  const [created] = await db
    .insert(contacts)
    .values({
      name,
      email: nullable(fd, "email"),
      phone: nullable(fd, "phone"),
      jobTitle: nullable(fd, "jobTitle"),
      companyId: optionalId(fd, "companyId"),
      status: (text(fd, "status") || "lead") as ContactStatus,
      source: nullable(fd, "source"),
      city: nullable(fd, "city"),
      notes: nullable(fd, "notes"),
      lastContactedAt: new Date(),
    })
    .returning({ id: contacts.id });

  if (created) {
    await db.insert(activities).values({
      type: "note",
      subject: "تمت إضافة العميل إلى النظام",
      body: nullable(fd, "notes") ?? "سجل عميل جديد تم إنشاؤه من لوحة العملاء.",
      contactId: created.id,
    });
  }
  refresh();
}

export async function updateContact(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db
    .update(contacts)
    .set({
      name: text(fd, "name"),
      email: nullable(fd, "email"),
      phone: nullable(fd, "phone"),
      jobTitle: nullable(fd, "jobTitle"),
      companyId: optionalId(fd, "companyId"),
      status: (text(fd, "status") || "lead") as ContactStatus,
      source: nullable(fd, "source"),
      city: nullable(fd, "city"),
      notes: nullable(fd, "notes"),
    })
    .where(eq(contacts.id, id));
  refresh();
}

export async function setContactStatus(id: number, status: ContactStatus) {
  if (!Number.isFinite(id)) return;
  await db.update(contacts).set({ status }).where(eq(contacts.id, id));
  refresh();
}

export async function deleteContact(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db.delete(contacts).where(eq(contacts.id, id));
  refresh();
  redirect("/contacts");
}

/* --------------------------------- companies -------------------------------- */

export async function createCompany(fd: FormData) {
  const name = text(fd, "name");
  if (!name) return;
  await db.insert(companies).values({
    name,
    industry: nullable(fd, "industry"),
    website: nullable(fd, "website"),
    phone: nullable(fd, "phone"),
    city: nullable(fd, "city"),
    employees: nullable(fd, "employees") ? numberField(fd, "employees") : null,
    notes: nullable(fd, "notes"),
  });
  refresh();
}

export async function updateCompany(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db
    .update(companies)
    .set({
      name: text(fd, "name"),
      industry: nullable(fd, "industry"),
      website: nullable(fd, "website"),
      phone: nullable(fd, "phone"),
      city: nullable(fd, "city"),
      employees: nullable(fd, "employees") ? numberField(fd, "employees") : null,
      notes: nullable(fd, "notes"),
    })
    .where(eq(companies.id, id));
  refresh();
}

export async function deleteCompany(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db.delete(companies).where(eq(companies.id, id));
  refresh();
}

/* ----------------------------------- deals ---------------------------------- */

export async function createDeal(fd: FormData) {
  const title = text(fd, "title");
  if (!title) return;
  const stage = (text(fd, "stage") || "lead") as DealStage;
  const [created] = await db
    .insert(deals)
    .values({
      title,
      companyId: optionalId(fd, "companyId"),
      contactId: optionalId(fd, "contactId"),
      stage,
      value: String(numberField(fd, "value")),
      currency: text(fd, "currency") || "EGP",
      probability: Math.min(100, Math.max(0, numberField(fd, "probability", 20))),
      owner: text(fd, "owner") || "أنت",
      source: nullable(fd, "source"),
      expectedCloseDate: nullable(fd, "expectedCloseDate"),
      notes: nullable(fd, "notes"),
    })
    .returning({ id: deals.id });

  if (created) {
    await db.insert(activities).values({
      type: "note",
      subject: `صفقة جديدة: ${title}`,
      body: "تم إنشاء الصفقة وإضافتها إلى خط الأنابيب.",
      dealId: created.id,
      contactId: optionalId(fd, "contactId"),
    });
  }
  refresh();
}

export async function updateDeal(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  const stage = (text(fd, "stage") || "lead") as DealStage;
  await db
    .update(deals)
    .set({
      title: text(fd, "title"),
      companyId: optionalId(fd, "companyId"),
      contactId: optionalId(fd, "contactId"),
      stage,
      value: String(numberField(fd, "value")),
      currency: text(fd, "currency") || "EGP",
      probability: Math.min(100, Math.max(0, numberField(fd, "probability", 20))),
      owner: text(fd, "owner") || "أنت",
      source: nullable(fd, "source"),
      expectedCloseDate: nullable(fd, "expectedCloseDate"),
      notes: nullable(fd, "notes"),
      updatedAt: new Date(),
    })
    .where(eq(deals.id, id));
  refresh();
}

export async function moveDealStage(id: number, stage: DealStage) {
  if (!Number.isFinite(id)) return;
  const probability = stage === "won" ? 100 : stage === "lost" ? 0 : undefined;
  await db
    .update(deals)
    .set({
      stage,
      updatedAt: new Date(),
      ...(probability !== undefined ? { probability } : {}),
    })
    .where(eq(deals.id, id));
  refresh();
}

export async function deleteDeal(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db.delete(deals).where(eq(deals.id, id));
  refresh();
}

/* ----------------------------------- tasks ---------------------------------- */

export async function createTask(fd: FormData) {
  const title = text(fd, "title");
  if (!title) return;
  await db.insert(tasks).values({
    title,
    description: nullable(fd, "description"),
    contactId: optionalId(fd, "contactId"),
    dealId: optionalId(fd, "dealId"),
    assignee: text(fd, "assignee") || "أنت",
    dueDate: nullable(fd, "dueDate"),
    priority: (text(fd, "priority") || "medium") as TaskPriority,
    status: (text(fd, "status") || "todo") as TaskStatus,
  });
  refresh();
}

export async function updateTask(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  const status = (text(fd, "status") || "todo") as TaskStatus;
  await db
    .update(tasks)
    .set({
      title: text(fd, "title"),
      description: nullable(fd, "description"),
      contactId: optionalId(fd, "contactId"),
      dealId: optionalId(fd, "dealId"),
      assignee: text(fd, "assignee") || "أنت",
      dueDate: nullable(fd, "dueDate"),
      priority: (text(fd, "priority") || "medium") as TaskPriority,
      status,
      completedAt: status === "done" ? new Date() : null,
    })
    .where(eq(tasks.id, id));
  refresh();
}

export async function toggleTask(id: number) {
  if (!Number.isFinite(id)) return;
  const [task] = await db
    .select({ status: tasks.status })
    .from(tasks)
    .where(eq(tasks.id, id))
    .limit(1);
  if (!task) return;
  const done = task.status === "done";
  await db
    .update(tasks)
    .set({
      status: done ? "todo" : "done",
      completedAt: done ? null : new Date(),
    })
    .where(eq(tasks.id, id));
  refresh();
}

export async function deleteTask(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db.delete(tasks).where(eq(tasks.id, id));
  refresh();
}

/* --------------------------------- activities -------------------------------- */

export async function addActivity(fd: FormData) {
  const subject = text(fd, "subject");
  if (!subject) return;
  await db.insert(activities).values({
    type: (text(fd, "type") || "note") as ActivityType,
    subject,
    body: nullable(fd, "body"),
    contactId: optionalId(fd, "contactId"),
    dealId: optionalId(fd, "dealId"),
    author: text(fd, "author") || "أنت",
  });
  if (optionalId(fd, "contactId")) {
    await db
      .update(contacts)
      .set({ lastContactedAt: new Date() })
      .where(eq(contacts.id, optionalId(fd, "contactId")!));
  }
  refresh();
}

export async function deleteActivity(fd: FormData) {
  const id = optionalId(fd, "id");
  if (!id) return;
  await db.delete(activities).where(eq(activities.id, id));
  refresh();
}
