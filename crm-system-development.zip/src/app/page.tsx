import Link from "next/link";
import { DealFormModal, TaskFormModal } from "@/components/forms";
import { Icon } from "@/components/icons";
import { TaskCheckbox } from "@/components/Interactive";
import {
  Avatar,
  EmptyState,
  PageHeader,
  ProgressBar,
  SectionCard,
  StatCard,
} from "@/components/ui";
import {
  activityTypeMeta,
  CONTACT_STATUSES,
  DEAL_STAGES,
  dueLabel,
  formatCompactMoney,
  formatMoney,
  formatNumber,
  priorityMeta,
  relativeTime,
  stageMeta,
} from "@/lib/format";
import { getDashboard, getOptions } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

const STATUS_COLORS: Record<string, string> = {
  lead: "#94a3b8",
  prospect: "#f59e0b",
  customer: "#10b981",
  churned: "#f43f5e",
};

export default async function DashboardPage() {
  await ensureSeed();
  const [data, options] = await Promise.all([getDashboard(), getOptions()]);
  const { metrics, stageTotals, monthly, statusMap } = data;

  const today = new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date());

  const maxStageValue = Math.max(...stageTotals.map((stage) => stage.value), 1);
  const maxMonthly = Math.max(...monthly.map((month) => month.won), 1);
  const totalContacts = Object.values(statusMap).reduce((sum, count) => sum + count, 0) || 1;

  let cursor = 0;
  const donutSegments = CONTACT_STATUSES.map((status) => {
    const count = statusMap[status.key] ?? 0;
    const percent = (count / totalContacts) * 100;
    const segment = `${STATUS_COLORS[status.key]} ${cursor}% ${cursor + percent}%`;
    cursor += percent;
    return { status, count, percent, segment };
  });
  const donutGradient = `conic-gradient(${donutSegments.map((item) => item.segment).join(", ")})`;

  const topDeals = data.topDeals.slice(0, 5);

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow={today}
        title="لوحة التحكم"
        description="نظرة شاملة على خط الصفقات، أداء الفريق، والمهام المستحقة اليوم."
      >
        <TaskFormModal
          contacts={options.contacts}
          deals={options.deals}
          triggerLabel="مهمة جديدة"
          triggerClass="btn-ghost"
          triggerIcon="check"
        />
        <DealFormModal
          companies={options.companies}
          contacts={options.contacts}
          triggerLabel="صفقة جديدة"
          triggerIcon="plus"
        />
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        <StatCard
          label="قيمة خط الأنابيب"
          value={formatCompactMoney(metrics.pipelineValue)}
          hint={`${formatNumber(metrics.openDeals)} صفقة مفتوحة`}
          icon="money"
          tone="indigo"
          trend={{ value: `${formatCompactMoney(metrics.weightedValue)} مرجّحة` }}
        />
        <StatCard
          label="مبيعات مُغلقة"
          value={formatCompactMoney(metrics.wonValue)}
          hint={`${formatCompactMoney(metrics.wonThisMonth)} هذا الشهر`}
          icon="target"
          tone="emerald"
          trend={{ value: `${formatNumber(metrics.winRate)}% نسبة الإغلاق` }}
        />
        <StatCard
          label="متوسط قيمة الصفقة"
          value={formatCompactMoney(metrics.avgDeal)}
          hint="محسوب على الصفقات المكسوبة"
          icon="chart"
          tone="violet"
        />
        <StatCard
          label="إجمالي العملاء"
          value={formatNumber(metrics.contacts)}
          hint={`${formatNumber(metrics.customers)} عميل حالي · ${formatNumber(metrics.newContacts)} جديد`}
          icon="users"
          tone="sky"
          trend={{
            value: `${formatNumber(metrics.overdueTasks)} مهمة متأخرة`,
            positive: metrics.overdueTasks === 0,
          }}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SectionCard
          title="حركة المبيعات"
          subtitle="قيمة الصفقات المكسوبة خلال آخر 6 أشهر"
          className="lg:col-span-2"
          action={
            <span className="chip bg-indigo-50 text-indigo-600">
              <Icon name="sparkle" className="h-3 w-3" />
              مباشر
            </span>
          }
          bodyClassName="p-4 lg:p-5"
        >
          <div className="flex h-[210px] items-end justify-between gap-2 pt-4">
            {monthly.map((month) => {
              const height = Math.max((month.won / maxMonthly) * 100, month.won > 0 ? 8 : 2);
              return (
                <div key={month.label} className="group flex flex-1 flex-col items-center gap-2">
                  <span className="text-[10px] font-semibold text-slate-400 opacity-0 transition group-hover:opacity-100">
                    {formatCompactMoney(month.won)}
                  </span>
                  <div className="flex h-full w-full items-end justify-center">
                    <div
                      className="w-full max-w-[54px] rounded-t-lg bg-gradient-to-t from-indigo-200 via-indigo-400 to-indigo-600 transition-all duration-500 group-hover:from-indigo-300 group-hover:to-violet-500"
                      style={{ height: `${height}%` }}
                    />
                  </div>
                  <div className="text-center">
                    <p className="text-[11px] font-medium text-slate-600">{month.label}</p>
                    <p className="text-[10px] text-slate-400">{month.created} صفقة</p>
                  </div>
                </div>
              );
            })}
          </div>
        </SectionCard>

        <SectionCard title="حالة قاعدة العملاء" subtitle="توزيع العملاء على مراحل العلاقة">
          <div className="flex items-center gap-5">
            <div className="relative h-[104px] w-[104px] shrink-0">
              <div
                className="h-full w-full rounded-full"
                style={{
                  background: metrics.contacts
                    ? donutGradient
                    : "conic-gradient(#e2e8f0 0% 100%)",
                }}
              />
              <div className="absolute inset-[14px] flex flex-col items-center justify-center rounded-full bg-white">
                <span className="text-lg font-bold text-slate-900">
                  {formatNumber(metrics.contacts)}
                </span>
                <span className="text-[9px] text-slate-400">عميل</span>
              </div>
            </div>
            <ul className="flex-1 space-y-2">
              {donutSegments.map((item) => (
                <li key={item.status.key} className="flex items-center gap-2 text-[11.5px]">
                  <span
                    className="h-2 w-2 rounded-full"
                    style={{ backgroundColor: STATUS_COLORS[item.status.key] }}
                  />
                  <span className="flex-1 text-slate-600">{item.status.label}</span>
                  <span className="font-semibold text-slate-800">{formatNumber(item.count)}</span>
                  <span className="w-9 text-left text-[10px] text-slate-400">
                    {Math.round(item.percent)}%
                  </span>
                </li>
              ))}
            </ul>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
            <div className="rounded-xl bg-slate-50 p-2.5">
              <p className="text-[10px] text-slate-400">مهام مفتوحة</p>
              <p className="text-sm font-bold text-slate-800">
                {formatNumber(metrics.openTasksCount)}
              </p>
            </div>
            <div className="rounded-xl bg-slate-50 p-2.5">
              <p className="text-[10px] text-slate-400">صفقات مغلقة</p>
              <p className="text-sm font-bold text-slate-800">
                {formatNumber(stageTotals.find((stage) => stage.stage === "won")?.count ?? 0)}
              </p>
            </div>
          </div>
        </SectionCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SectionCard
          title="مراحل خط الأنابيب"
          subtitle="القيمة التراكمية لكل مرحلة"
          className="lg:col-span-2"
          action={
            <Link href="/deals" className="chip bg-slate-100 text-slate-600 hover:bg-slate-200">
              فتح اللوحة
              <Icon name="arrow" className="h-3 w-3" />
            </Link>
          }
        >
          <ul className="space-y-3.5">
            {stageTotals.map((stage) => {
              const meta = stageMeta(stage.stage);
              return (
                <li key={stage.stage}>
                  <div className="mb-1.5 flex items-center justify-between gap-2 text-[12px]">
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${meta.dot}`} />
                      <span className="font-medium text-slate-700">{meta.label}</span>
                      <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500">
                        {formatNumber(stage.count)}
                      </span>
                    </div>
                    <span className="font-semibold text-slate-800">
                      {formatCompactMoney(stage.value)}
                    </span>
                  </div>
                  <ProgressBar
                    value={(stage.value / maxStageValue) * 100}
                    className={meta.dot}
                    height="h-2"
                  />
                </li>
              );
            })}
          </ul>
        </SectionCard>

        <SectionCard
          title="مهام تحتاج إنجازاً"
          subtitle="الأقرب موعداً أولاً"
          action={
            <Link href="/tasks" className="text-[11px] font-semibold text-indigo-600 hover:underline">
              كل المهام
            </Link>
          }
          bodyClassName="p-2"
        >
          {data.upcomingTasks.length ? (
            <ul className="divide-y divide-slate-100">
              {data.upcomingTasks.slice(0, 5).map((task) => {
                const priority = priorityMeta(task.priority);
                const overdue =
                  task.dueDate && task.dueDate < new Date().toISOString().slice(0, 10);
                return (
                  <li key={task.id} className="flex items-start gap-2.5 px-2 py-2.5">
                    <TaskCheckbox id={task.id} done={false} label={task.title} />
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-2 text-[12.5px] font-medium leading-5 text-slate-800">
                        {task.title}
                      </p>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5">
                        <span className={`chip border ${priority.soft}`}>{priority.label}</span>
                        <span
                          className={`text-[10px] ${overdue ? "font-semibold text-rose-500" : "text-slate-400"}`}
                        >
                          {dueLabel(task.dueDate)}
                        </span>
                        {task.contactName && (
                          <span className="text-[10px] text-slate-400">· {task.contactName}</span>
                        )}
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : (
            <EmptyState icon="check" title="لا مهام مفتوحة" description="كل شيء منجز، أحسنت!" />
          )}
        </SectionCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SectionCard
          title="أهم الصفقات المفتوحة"
          subtitle="مرتبة حسب القيمة"
          className="lg:col-span-2"
          action={
            <Link href="/deals" className="text-[11px] font-semibold text-indigo-600 hover:underline">
              إدارة الصفقات
            </Link>
          }
          bodyClassName="p-0"
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] border-collapse">
              <thead className="bg-slate-50/70">
                <tr>
                  <th className="th">الصفقة</th>
                  <th className="th">المرحلة</th>
                  <th className="th">القيمة</th>
                  <th className="th">المسؤول</th>
                </tr>
              </thead>
              <tbody>
                {topDeals.map((deal) => {
                  const meta = stageMeta(deal.stage);
                  return (
                    <tr key={deal.id} className="border-t border-slate-100">
                      <td className="td">
                        <p className="text-[12.5px] font-semibold text-slate-800">{deal.title}</p>
                        <p className="text-[10.5px] text-slate-400">{deal.companyName ?? "—"}</p>
                      </td>
                      <td className="td">
                        <span className={`chip ${meta.soft}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
                          {meta.label}
                        </span>
                      </td>
                      <td className="td whitespace-nowrap font-semibold text-slate-900">
                        {formatMoney(deal.value)}
                      </td>
                      <td className="td">
                        <div className="flex items-center gap-1.5">
                          <Avatar name={deal.owner} size="sm" />
                          <span className="hidden text-[11.5px] text-slate-600 sm:block">
                            {deal.owner}
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard
          title="آخر الأنشطة"
          subtitle="ما يحدث الآن في فريقك"
          action={
            <Link href="/contacts" className="text-[11px] font-semibold text-indigo-600 hover:underline">
              كل العملاء
            </Link>
          }
          bodyClassName="p-4"
        >
          <ol className="relative space-y-4 border-r border-slate-100 pr-4">
            {data.recentActivities.map((activity) => {
              const meta = activityTypeMeta(activity.type);
              return (
                <li key={activity.id} className="relative">
                  <span className="absolute -right-[25px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-white ring-2 ring-slate-100">
                    <span className="h-1.5 w-1.5 rounded-full bg-indigo-400" />
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className={`chip ${meta.soft}`}>
                      <span>{meta.icon}</span>
                      {meta.label}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {relativeTime(activity.createdAt)}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] font-medium leading-5 text-slate-800">
                    {activity.subject}
                  </p>
                  {(activity.contactName || activity.dealTitle) && (
                    <p className="text-[10.5px] text-slate-400">
                      {activity.contactName ?? activity.dealTitle}
                    </p>
                  )}
                </li>
              );
            })}
          </ol>
        </SectionCard>
      </div>

      <div className="card flex flex-col items-start justify-between gap-4 bg-gradient-to-l from-indigo-600 via-indigo-600 to-violet-600 p-5 text-white sm:flex-row sm:items-center">
        <div>
          <p className="text-[15px] font-semibold">
            {metrics.pipelineValue > 0 ? "خط أنابيبك يتحرك 🚀" : "لنبدأ أول صفقة"}
          </p>
          <p className="mt-1 max-w-xl text-[12px] leading-6 text-indigo-100">
            لديك {formatNumber(metrics.openDeals)} صفقة مفتوحة بقيمة{" "}
            {formatCompactMoney(metrics.pipelineValue)}. الصفقات التي تتابعها خلال 48 ساعة
            ترتفع فرص إغلاقها بشكل واضح.
          </p>
        </div>
        <Link
          href="/deals"
          className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-[13px] font-semibold text-indigo-700 transition hover:bg-indigo-50"
        >
          متابعة خط الصفقات
          <Icon name="arrow" className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
