import Link from "next/link";
import { deleteTask } from "@/app/actions";
import { FilterBar } from "@/components/Filters";
import { TaskFormModal } from "@/components/forms";
import { Icon } from "@/components/icons";
import { DeleteButton, TaskCheckbox } from "@/components/Interactive";
import { Avatar, EmptyState, PageHeader, ProgressBar, SectionCard } from "@/components/ui";
import {
  dueLabel,
  formatNumber,
  priorityMeta,
  TASK_STATUSES,
  taskStatusMeta,
  TEAM,
} from "@/lib/format";
import { getOptions, getTasks } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

type TaskFilter = "all" | "open" | "done" | "today" | "overdue";

const TABS: { key: TaskFilter; label: string }[] = [
  { key: "all", label: "الكل" },
  { key: "open", label: "مفتوحة" },
  { key: "today", label: "اليوم" },
  { key: "overdue", label: "متأخرة" },
  { key: "done", label: "مكتملة" },
];

export default async function TasksPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; assignee?: string; search?: string }>;
}) {
  await ensureSeed();
  const params = await searchParams;
  const status = (TABS.find((tab) => tab.key === params.status)?.key ?? "all") as TaskFilter;

  const [allTasks, tasks, options] = await Promise.all([
    getTasks(),
    getTasks({ status, assignee: params.assignee }),
    getOptions(),
  ]);

  const filtered = params.search
    ? tasks.filter((task) =>
        `${task.title} ${task.description ?? ""} ${task.contactName ?? ""}`
          .toLowerCase()
          .includes(params.search!.toLowerCase()),
      )
    : tasks;

  const today = new Date().toISOString().slice(0, 10);
  const counts = {
    open: allTasks.filter((task) => task.status !== "done").length,
    today: allTasks.filter((task) => task.status !== "done" && task.dueDate === today).length,
    overdue: allTasks.filter(
      (task) => task.status !== "done" && task.dueDate && task.dueDate < today,
    ).length,
    done: allTasks.filter((task) => task.status === "done").length,
  };

  const byAssignee = [...TEAM, "أنت"].map((member) => {
    const memberTasks = allTasks.filter((task) => task.assignee === member);
    return {
      member,
      total: memberTasks.length,
      open: memberTasks.filter((task) => task.status !== "done").length,
      done: memberTasks.filter((task) => task.status === "done").length,
    };
  });

  return (
    <div>
      <PageHeader
        title="المهام"
        description="كل ما يحتاج متابعة — مرتب حسب الموعد والمسؤول، مع إمكانية الإنجاز بضغطة."
      >
        <TaskFormModal
          contacts={options.contacts}
          deals={options.deals}
          triggerLabel="مهمة جديدة"
        />
      </PageHeader>

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { label: "مهام مفتوحة", value: counts.open, tone: "bg-indigo-50 text-indigo-600", icon: "check" as const, key: "open" },
          { label: "مستحقة اليوم", value: counts.today, tone: "bg-amber-50 text-amber-600", icon: "clock" as const, key: "today" },
          { label: "متأخرة", value: counts.overdue, tone: "bg-rose-50 text-rose-600", icon: "flag" as const, key: "overdue" },
          { label: "مكتملة", value: counts.done, tone: "bg-emerald-50 text-emerald-600", icon: "target" as const, key: "done" },
        ].map((item) => (
          <Link key={item.key} href={item.key === "open" ? "/tasks" : `/tasks?status=${item.key}`} className="card flex items-center gap-3 p-4 transition hover:-translate-y-0.5 hover:shadow-md">
            <span className={`flex h-10 w-10 items-center justify-center rounded-xl ${item.tone}`}>
              <Icon name={item.icon} className="h-5 w-5" />
            </span>
            <div>
              <p className="text-[11px] text-slate-500">{item.label}</p>
              <p className="text-lg font-bold text-slate-900">{formatNumber(item.value)}</p>
            </div>
          </Link>
        ))}
      </div>

      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-1 rounded-xl border border-slate-200 bg-white p-1">
          {TABS.map((tab) => {
            const active = status === tab.key;
            return (
              <Link
                key={tab.key}
                href={
                  tab.key === "all"
                    ? "/tasks"
                    : `/tasks?status=${tab.key}${params.assignee ? `&assignee=${encodeURIComponent(params.assignee)}` : ""}`
                }
                className={`rounded-lg px-3 py-1.5 text-[12px] font-medium transition ${
                  active ? "bg-slate-900 text-white" : "text-slate-500 hover:bg-slate-100"
                }`}
              >
                {tab.label}
              </Link>
            );
          })}
        </div>
        <span className="text-[11px] text-slate-400">{formatNumber(filtered.length)} مهمة معروضة</span>
      </div>

      <FilterBar
        basePath="/tasks"
        placeholder="ابحث في المهام…"
        searchValue={params.search ?? ""}
        values={{ status: status === "all" ? "all" : status, assignee: params.assignee ?? "all" }}
        selects={[
          {
            name: "assignee",
            label: "المسؤول",
            options: [...TEAM, "أنت"].map((member) => ({ value: member, label: member })),
          },
        ]}
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card overflow-hidden lg:col-span-2">
          {filtered.length ? (
            <ul className="divide-y divide-slate-100">
              {filtered.map((task) => {
                const priority = priorityMeta(task.priority);
                const statusMeta = taskStatusMeta(task.status);
                const done = task.status === "done";
                const overdue = !done && task.dueDate && task.dueDate < today;
                return (
                  <li
                    key={task.id}
                    className={`flex items-start gap-3 px-4 py-3.5 transition hover:bg-slate-50/60 ${done ? "opacity-70" : ""}`}
                  >
                    <TaskCheckbox id={task.id} done={done} label={task.title} />
                    <div className="min-w-0 flex-1">
                      <p
                        className={`text-[13.5px] font-semibold leading-6 ${
                          done ? "text-slate-400 line-through" : "text-slate-800"
                        }`}
                      >
                        {task.title}
                      </p>
                      {task.description && (
                        <p className="mt-0.5 line-clamp-2 text-[11.5px] leading-5 text-slate-500">
                          {task.description}
                        </p>
                      )}
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                        <span className={`chip border ${priority.soft}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${priority.dot}`} />
                          {priority.label}
                        </span>
                        <span className="chip bg-slate-100 text-slate-600">{statusMeta.label}</span>
                        {task.contactName && task.contactId && (
                          <Link
                            href={`/contacts/${task.contactId}`}
                            className="chip bg-indigo-50 text-indigo-700 hover:bg-indigo-100"
                          >
                            <Icon name="users" className="h-3 w-3" />
                            {task.contactName}
                          </Link>
                        )}
                        {task.dealTitle && (
                          <span className="chip bg-violet-50 text-violet-700">
                            <Icon name="pipeline" className="h-3 w-3" />
                            {task.dealTitle}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-2">
                      <span
                        className={`text-[10.5px] font-semibold ${overdue ? "text-rose-500" : done ? "text-emerald-600" : "text-slate-400"}`}
                      >
                        {done ? "مكتملة" : dueLabel(task.dueDate)}
                      </span>
                      <div className="flex items-center gap-1">
                        <TaskFormModal
                          contacts={options.contacts}
                          deals={options.deals}
                          initial={task}
                          triggerLabel=""
                          triggerIcon="edit"
                          triggerClass="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                        />
                        <DeleteButton
                          id={task.id}
                          action={deleteTask}
                          className="rounded-md p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                        />
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          ) : (
            <div className="p-4">
              <EmptyState
                icon="check"
                title="لا مهام في هذا التصنيف"
                description="أنشئ مهمة جديدة أو غيّر الفلتر لعرض مهام أخرى."
              />
            </div>
          )}
        </div>

        <div className="space-y-4">
          <SectionCard title="توزيع الفريق" subtitle="حِمل العمل الحالي" bodyClassName="p-4">
            <ul className="space-y-3.5">
              {byAssignee.map((member) => (
                <li key={member.member}>
                  <div className="mb-1.5 flex items-center gap-2">
                    <Avatar name={member.member} size="sm" />
                    <span className="flex-1 text-[12px] font-medium text-slate-700">
                      {member.member}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {formatNumber(member.open)} مفتوحة
                    </span>
                  </div>
                  <ProgressBar
                    value={member.total ? (member.done / member.total) * 100 : 0}
                    className="bg-emerald-500"
                    height="h-1.5"
                  />
                </li>
              ))}
            </ul>
          </SectionCard>

          <SectionCard title="حالات المهام" bodyClassName="p-4">
            <ul className="space-y-2.5">
              {TASK_STATUSES.map((item) => {
                const count = allTasks.filter((task) => task.status === item.key).length;
                return (
                  <li
                    key={item.key}
                    className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2.5 text-[12px]"
                  >
                    <span className="text-slate-600">{item.label}</span>
                    <span className="font-semibold text-slate-800">{formatNumber(count)}</span>
                  </li>
                );
              })}
            </ul>
            <div className="mt-3 rounded-xl bg-indigo-50 p-3">
              <p className="text-[11px] font-semibold text-indigo-800">نصيحة</p>
              <p className="mt-1 text-[11px] leading-5 text-indigo-700/80">
                ابدأ المهام المتأخرة أولاً، ثم المهام المستحقة اليوم. وضع موعد لكل مهمة
                يرفع الالتزام بشكل واضح.
              </p>
            </div>
          </SectionCard>
        </div>
      </div>
    </div>
  );
}
