import Link from "next/link";
import { Logo } from "@/components/icons";

export default function NotFound() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4 text-center">
      <Logo size={52} />
      <div>
        <p className="text-[13px] font-semibold text-indigo-600">404</p>
        <h1 className="mt-1 text-2xl font-bold text-slate-900">الصفحة غير موجودة</h1>
        <p className="mt-1 max-w-sm text-[13px] leading-6 text-slate-500">
          ربما تم حذف هذا السجل أو تغيّر الرابط. يمكنك العودة إلى لوحة التحكم ومتابعة
          العمل.
        </p>
      </div>
      <Link href="/" className="btn-primary">
        العودة إلى لوحة التحكم
      </Link>
    </div>
  );
}
