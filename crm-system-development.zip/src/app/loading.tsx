export default function Loading() {
  return (
    <div className="space-y-5">
      <div className="h-8 w-48 animate-pulse rounded-lg bg-slate-200/70" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <div key={index} className="card h-[120px] animate-pulse bg-white/70" />
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card h-[280px] animate-pulse bg-white/70 lg:col-span-2" />
        <div className="card h-[280px] animate-pulse bg-white/70" />
      </div>
      <div className="card h-[220px] animate-pulse bg-white/70" />
    </div>
  );
}
