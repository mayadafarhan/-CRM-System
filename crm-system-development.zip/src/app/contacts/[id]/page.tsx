import Link from "next/link";
import { notFound } from "next/navigation";
import { deleteContact } from "@/app/actions";
import {
  ActivityComposer,
  ContactFormModal,
  ContactStatusControl,
  DealFormModal,
  TaskFormModal,
  type ContactOption,
} from "@/components/forms";
import { Icon } from "@/components/icons";
import { DeleteButton, TaskCheckbox } from "@/components/Interactive";
import { Avatar, EmptyState, SectionCard } from "@/components/ui";
import {
  activityTypeMeta,
  contactStatusMeta,
  dueLabel,
  formatDate,
  formatMoney,
  formatShortDate,
  priorityMeta,
  relativeTime,
  stageMeta,
} from "@/lib/format";
import { getCompanies, getContactDetail, getOptions } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function ContactDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await ensureSeed();
  const { id } = await params;
  const contactId = Number(id);
  if (!Number.isFinite(contactId)) notFound();

  const [data, companies, options] = await Promise.all([
    getContactDetail(contactId),
    getCompanies(),
    getOptions(),
  ]);

  if (!data) notFound();

  const { contact, deals, tasks, activities } = data;
  const meta = contactStatusMeta(contact.status);
  const openDeals = deals.filter((deal) => !["won", "lost"].includes(deal.stage));
  const openValue = openDeals.reduce((sum, deal) => sum + Number(deal.value), 0);
  const contactOption: ContactOption = {
    id: contact.id,
    name: contact.name,
    companyId: contact.companyId,
  };

  return (
    <div className="space-y-5">
      <nav className="flex items-center gap-1.5 text-[12px] text-slate-400">
        <Link href="/contacts" className="hover:text-indigo-600">
          العملاء
        </Link>
        <Icon name="chevron" className="h-3.5 w-3.5 rotate-180" />
        <span className="font-medium text-slate-600">{contact.name}</span>
      </nav>

      <div className="card relative overflow-hidden">
        <div className="h-24 bg-gradient-to-l from-indigo-500 via-indigo-600 to-violet-600">
          <div className="grid-pattern h-full w-full opacity-30" />
        </div>
        <div className="flex flex-col gap-4 px-5 pb-5">
          <div className="-mt-9 flex flex-wrap items-end justify-between gap-4">
            <div className="flex items-end gap-3">
              <Avatar name={contact.name} size="xl" className="ring-4 ring-white" />
              <div className="pb-1">
                <h1 className="text-xl font-bold text-slate-900">{contact.name}</h1>
                <p className="text-[12.5px] text-slate-500">
                  {contact.jobTitle ?? "بدون مسمى وظيفي"}
                  {contact.companyName ? ` · ${contact.companyName}` : ""}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 pb-1">
              <TaskFormModal
                contacts={options.contacts}
                deals={options.deals}
                defaultContactId={contact.id}
                triggerLabel="مهمة"
                triggerClass="btn-ghost"
                triggerIcon="check"
              />
              <DealFormModal
                companies={companies}
                contacts={options.contacts}
                triggerLabel="صفقة"
                triggerClass="btn-ghost"
                triggerIcon="pipeline"
              />
              <ContactFormModal
                companies={companies}
                initial={contact}
                triggerLabel="تعديل"
                triggerClass="btn-ghost"
                triggerIcon="edit"
              />
              <DeleteButton
                id={contact.id}
                action={deleteContact}
                label="حذف"
                className="btn border border-rose-200 bg-white text-rose-600 hover:bg-rose-50"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <span className={`chip ${meta.soft}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
              {meta.label}
            </span>
            {contact.source && (
              <span className="chip bg-slate-100 text-slate-600">المصدر: {contact.source}</span>
            )}
            <span className="chip bg-slate-100 text-slate-600">
              آخر تواصل: {relativeTime(contact.lastContactedAt)}
            </span>
            <span className="chip bg-indigo-50 text-indigo-700">
              {openDeals.length} صفقة مفتوحة · {formatMoney(openValue)}
            </span>
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <SectionCard
            title="الصفقات المرتبطة"
            subtitle={`${deals.length} صفقة · ${formatMoney(deals.reduce((sum, deal) => sum + Number(deal.value), 0))}`}
            bodyClassName="p-0"
          >
            {deals.length ? (
              <ul className="divide-y divide-slate-100">
                {deals.map((deal) => {
                  const stage = stageMeta(deal.stage);
                  return (
                    <li
                      key={deal.id}
                      className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 hover:bg-slate-50/60"
                    >
                      <div className="min-w-0">
                        <p className="text-[13px] font-semibold text-slate-800">{deal.title}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-2">
                          <span className={`chip ${stage.soft}`}>
                            <span className={`h-1.5 w-1.5 rounded-full ${stage.dot}`} />
                            {stage.label}
                          </span>
                          <span className="text-[10.5px] text-slate-400">
                            إغلاق متوقع {formatShortDate(deal.expectedCloseDate)}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <p className="text-[13px] font-bold text-slate-900">
                          {formatMoney(deal.value, deal.currency)}
                        </p>
                        <DealFormModal
                          companies={companies}
                          contacts={options.contacts}
                          initial={deal}
                          triggerLabel=""
                          triggerIcon="edit"
                          triggerClass="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                        />
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <div className="p-4">
                <EmptyState
                  icon="pipeline"
                  title="لا توجد صفقات بعد"
                  description="ابدأ صفقة جديدة لهذا العميل لتتبع قيمتها ومرحلتها."
                />
              </div>
            )}
          </SectionCard>

          <SectionCard
            title="سجل الأنشطة"
            subtitle="مكالمات، اجتماعات، بريد وملاحظات"
            bodyClassName="p-4 lg:p-5"
          >
            <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-3">
              <ActivityComposer contactId={contact.id} deals={options.deals} />
            </div>

            {activities.length ? (
              <ol className="mt-5 space-y-4 border-r border-slate-100 pr-4">
                {activities.map((activity) => {
                  const type = activityTypeMeta(activity.type);
                  return (
                    <li key={activity.id} className="relative">
                      <span className="absolute -right-[25px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-white ring-2 ring-slate-100">
                        <span className="h-1.5 w-1.5 rounded-full bg-indigo-400" />
                      </span>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`chip ${type.soft}`}>
                          <span>{type.icon}</span>
                          {type.label}
                        </span>
                        <p className="text-[12.5px] font-semibold text-slate-800">
                          {activity.subject}
                        </p>
                        <span className="text-[10.5px] text-slate-400">
                          {relativeTime(activity.createdAt)} · {activity.author}
                        </span>
                      </div>
                      {activity.body && (
                        <p className="mt-1 text-[12px] leading-6 text-slate-500">{activity.body}</p>
                      )}
                    </li>
                  );
                })}
              </ol>
            ) : (
              <p className="mt-4 text-center text-[12px] text-slate-400">
                لا يوجد نشاط مسجل بعد — سجّل أول مكالمة أو ملاحظة.
              </p>
            )}
          </SectionCard>
        </div>

        <div className="space-y-4">
          <SectionCard title="بيانات الاتصال" bodyClassName="p-4">
            <div className="mb-3">
              <span className="label">حالة العلاقة</span>
              <ContactStatusControl contactId={contact.id} status={contact.status} />
            </div>
            <ul className="space-y-3 text-[12.5px]">
              {contact.email && (
                <li className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                    <Icon name="mail" className="h-4 w-4" />
                  </span>
                  <a
                    href={`mailto:${contact.email}`}
                    dir="ltr"
                    className="truncate text-left text-slate-700 hover:text-indigo-600"
                  >
                    {contact.email}
                  </a>
                </li>
              )}
              {contact.phone && (
                <li className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                    <Icon name="phone" className="h-4 w-4" />
                  </span>
                  <a href={`tel:${contact.phone}`} dir="ltr" className="text-slate-700">
                    {contact.phone}
                  </a>
                </li>
              )}
              {contact.companyName && (
                <li className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                    <Icon name="building" className="h-4 w-4" />
                  </span>
                  <span className="text-slate-700">
                    {contact.companyName}
                    {contact.companyIndustry ? ` · ${contact.companyIndustry}` : ""}
                  </span>
                </li>
              )}
              {contact.city && (
                <li className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                    <Icon name="target" className="h-4 w-4" />
                  </span>
                  <span className="text-slate-700">{contact.city}</span>
                </li>
              )}
              <li className="flex items-center gap-2.5">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                  <Icon name="calendar" className="h-4 w-4" />
                </span>
                <span className="text-slate-500">أُضيف في {formatDate(contact.createdAt)}</span>
              </li>
            </ul>
          </SectionCard>

          <SectionCard
            title="المهام"
            subtitle={`${tasks.filter((task) => task.status !== "done").length} مهمة مفتوحة`}
            action={
              <TaskFormModal
                contacts={[contactOption]}
                deals={options.deals}
                defaultContactId={contact.id}
                triggerLabel=""
                triggerIcon="plus"
                triggerClass="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
              />
            }
            bodyClassName="p-2"
          >
            {tasks.length ? (
              <ul className="divide-y divide-slate-100">
                {tasks.map((task) => {
                  const priority = priorityMeta(task.priority);
                  return (
                    <li key={task.id} className="flex items-start gap-2.5 px-2 py-2.5">
                      <TaskCheckbox
                        id={task.id}
                        done={task.status === "done"}
                        label={task.title}
                      />
                      <div className="min-w-0 flex-1">
                        <p
                          className={`text-[12.5px] font-medium leading-5 ${
                            task.status === "done"
                              ? "text-slate-400 line-through"
                              : "text-slate-800"
                          }`}
                        >
                          {task.title}
                        </p>
                        <div className="mt-1 flex flex-wrap items-center gap-1.5">
                          <span className={`chip border ${priority.soft}`}>{priority.label}</span>
                          <span className="text-[10px] text-slate-400">{dueLabel(task.dueDate)}</span>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="px-2 py-6 text-center text-[12px] text-slate-400">
                لا مهام مرتبطة بهذا العميل.
              </p>
            )}
          </SectionCard>

          {contact.notes && (
            <SectionCard title="ملاحظات" bodyClassName="p-4">
              <p className="rounded-xl bg-amber-50/70 p-3 text-[12px] leading-6 text-slate-700 ring-1 ring-amber-100">
                {contact.notes}
              </p>
            </SectionCard>
          )}
        </div>
      </div>
    </div>
  );
}
