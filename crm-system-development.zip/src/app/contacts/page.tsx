import Link from "next/link";
import { deleteContact } from "@/app/actions";
import { FilterBar } from "@/components/Filters";
import { ContactFormModal } from "@/components/forms";
import { Icon } from "@/components/icons";
import { DeleteButton } from "@/components/Interactive";
import { Avatar, EmptyState, PageHeader } from "@/components/ui";
import {
  contactStatusMeta,
  CONTACT_STATUSES,
  formatNumber,
  relativeTime,
  SALES_SOURCES,
} from "@/lib/format";
import {
  getCompanies,
  getContacts,
  getOpenDealCountForContactIds,
} from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";
import type { ContactStatus } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function ContactsPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string; status?: string; source?: string }>;
}) {
  await ensureSeed();
  const params = await searchParams;
  const status = CONTACT_STATUSES.find((item) => item.key === params.status)?.key;

  const [allContacts, contacts, companies] = await Promise.all([
    getContacts(),
    getContacts({
      search: params.search,
      status: status as ContactStatus | undefined,
    }),
    getCompanies(),
  ]);

  const visible = params.source
    ? contacts.filter((contact) => contact.source === params.source)
    : contacts;

  const openDealCounts = await getOpenDealCountForContactIds(
    visible.map((contact) => contact.id),
  );

  const counts = {
    total: allContacts.length,
    customers: allContacts.filter((contact) => contact.status === "customer").length,
    prospects: allContacts.filter((contact) => contact.status === "prospect").length,
    leads: allContacts.filter((contact) => contact.status === "lead").length,
  };

  return (
    <div>
      <PageHeader
        title="العملاء"
        description="كل جهات الاتصال في مكان واحد مع حالة العلاقة، الشركة، وآخر تواصل."
      >
        <ContactFormModal companies={companies} triggerLabel="عميل جديد" />
      </PageHeader>

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="card flex items-center gap-3 p-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
            <Icon name="users" className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] text-slate-500">إجمالي العملاء</p>
            <p className="text-lg font-bold text-slate-900">{formatNumber(counts.total)}</p>
          </div>
        </div>
        <div className="card flex items-center gap-3 p-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
            <Icon name="check" className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] text-slate-500">عملاء حاليون</p>
            <p className="text-lg font-bold text-slate-900">{formatNumber(counts.customers)}</p>
          </div>
        </div>
        <div className="card flex items-center gap-3 p-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-600">
            <Icon name="pipeline" className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] text-slate-500">تحت التفاوض</p>
            <p className="text-lg font-bold text-slate-900">{formatNumber(counts.prospects)}</p>
          </div>
        </div>
        <div className="card flex items-center gap-3 p-4">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-50 text-sky-600">
            <Icon name="sparkle" className="h-5 w-5" />
          </span>
          <div>
            <p className="text-[11px] text-slate-500">عملاء محتملون</p>
            <p className="text-lg font-bold text-slate-900">{formatNumber(counts.leads)}</p>
          </div>
        </div>
      </div>

      <FilterBar
        basePath="/contacts"
        placeholder="ابحث بالاسم، البريد، الهاتف، أو الشركة…"
        searchValue={params.search ?? ""}
        values={{ status: params.status ?? "all", source: params.source ?? "all" }}
        selects={[
          {
            name: "status",
            label: "الحالة",
            options: CONTACT_STATUSES.map((item) => ({ value: item.key, label: item.label })),
          },
          {
            name: "source",
            label: "المصدر",
            options: SALES_SOURCES.map((source) => ({ value: source, label: source })),
          },
        ]}
      />

      <div className="card overflow-hidden">
        {visible.length ? (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] border-collapse">
              <thead className="bg-slate-50/80">
                <tr>
                  <th className="th">العميل</th>
                  <th className="th">الشركة</th>
                  <th className="th">الحالة</th>
                  <th className="th">بيانات التواصل</th>
                  <th className="th">المصدر</th>
                  <th className="th">صفقات مفتوحة</th>
                  <th className="th">آخر تواصل</th>
                  <th className="th"></th>
                </tr>
              </thead>
              <tbody>
                {visible.map((contact) => {
                  const meta = contactStatusMeta(contact.status);
                  return (
                    <tr
                      key={contact.id}
                      className="group border-t border-slate-100 transition hover:bg-slate-50/60"
                    >
                      <td className="td">
                        <Link href={`/contacts/${contact.id}`} className="flex items-center gap-2.5">
                          <Avatar name={contact.name} />
                          <div className="min-w-0">
                            <p className="truncate text-[13px] font-semibold text-slate-800 group-hover:text-indigo-700">
                              {contact.name}
                            </p>
                            <p className="truncate text-[11px] text-slate-400">
                              {contact.jobTitle ?? "بدون مسمى وظيفي"}
                            </p>
                          </div>
                        </Link>
                      </td>
                      <td className="td text-[12.5px]">
                        {contact.companyName ?? <span className="text-slate-300">—</span>}
                      </td>
                      <td className="td">
                        <span className={`chip ${meta.soft}`}>
                          <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
                          {meta.label}
                        </span>
                      </td>
                      <td className="td">
                        <div className="space-y-1 text-[11.5px] text-slate-500">
                          {contact.phone && (
                            <p dir="ltr" className="text-right">
                              {contact.phone}
                            </p>
                          )}
                          {contact.email && (
                            <p dir="ltr" className="truncate text-right text-slate-400">
                              {contact.email}
                            </p>
                          )}
                        </div>
                      </td>
                      <td className="td text-[12px] text-slate-500">{contact.source ?? "—"}</td>
                      <td className="td">
                        <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-lg bg-indigo-50 px-1.5 text-[11px] font-semibold text-indigo-700">
                          {openDealCounts.get(contact.id) ?? 0}
                        </span>
                      </td>
                      <td className="td text-[11.5px] text-slate-400">
                        {relativeTime(contact.lastContactedAt)}
                      </td>
                      <td className="td">
                        <div className="flex items-center gap-1">
                          <Link
                            href={`/contacts/${contact.id}`}
                            className="rounded-md p-1.5 text-slate-400 transition hover:bg-indigo-50 hover:text-indigo-600"
                            aria-label="عرض"
                          >
                            <Icon name="external" className="h-3.5 w-3.5" />
                          </Link>
                          <ContactFormModal
                            companies={companies}
                            initial={contact}
                            triggerLabel=""
                            triggerIcon="edit"
                            triggerClass="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                          />
                          <DeleteButton id={contact.id} action={deleteContact} />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-4">
            <EmptyState
              icon="users"
              title="لا توجد نتائج"
              description="جرّب تعديل كلمات البحث أو أضف عميلاً جديداً لبدء المتابعة."
            />
          </div>
        )}
      </div>

      <p className="mt-3 text-[11px] text-slate-400">
        عرض {formatNumber(visible.length)} من {formatNumber(allContacts.length)} عميل
      </p>
    </div>
  );
}
