import { Icon } from "@/components/icons";
import { PageHeader, ProgressBar, SectionCard, StatCard } from "@/components/ui";
import {
  CONTACT_STATUSES,
  DEAL_STAGES,
  formatCompactMoney,
  formatMoney,
  formatNumber,
  stageMeta,
} from "@/lib/format";
import { getReports } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  await ensureSeed();
  const report = await getReports();

  const openStages = report.stageTotals.filter((stage) =>
    ["lead", "qualified", "proposal", "negotiation"].includes(stage.stage),
  );
  const wonStage = report.stageTotals.find((stage) => stage.stage === "won");
  const lostStage = report.stageTotals.find((stage) => stage.stage === "lost");
  const pipelineValue = openStages.reduce((sum, stage) => sum + stage.value, 0);
  const wonValue = wonStage?.value ?? 0;
  const winRate =
    (wonStage?.count ?? 0) + (lostStage?.count ?? 0) > 0
      ? Math.round(
          ((wonStage?.count ?? 0) / ((wonStage?.count ?? 0) + (lostStage?.count ?? 0))) * 100,
        )
      : 0;
  const maxMonthly = Math.max(...report.monthly.map((month) => month.value), 1);
  const maxSource = Math.max(...report.sources.map((source) => source.total), 1);
  const maxOwner = Math.max(...report.owners.map((owner) => owner.total), 1);
  const statusTotal =
    report.contactsByStatus.reduce((sum, row) => sum + row.count, 0) || 1;

  return (
    <div className="space-y-5">
      <PageHeader
        title="التقارير"
        description="قراءة تحليلية لأداء المبيعات: القمع، المصادر، وأداء كل مندوب."
      >
        <a href="/api/export" className="btn-ghost">
          <Icon name="external" className="h-4 w-4" />
          تصدير الصفقات CSV
        </a>
      </PageHeader>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard
          label="إجمالي الصفقات"
          value={formatNumber(report.totalDeals)}
          hint={`${formatNumber(openStages.reduce((sum, stage) => sum + stage.count, 0))} صفقة مفتوحة`}
          icon="pipeline"
          tone="indigo"
        />
        <StatCard
          label="قيمة خط الأنابيب"
          value={formatCompactMoney(pipelineValue)}
          hint="الصفقات غير المغلقة"
          icon="money"
          tone="sky"
        />
        <StatCard
          label="إجمالي المبيعات"
          value={formatCompactMoney(wonValue)}
          hint={`${formatNumber(wonStage?.count ?? 0)} صفقة مكسوبة`}
          icon="target"
          tone="emerald"
        />
        <StatCard
          label="نسبة الإغلاق"
          value={`${formatNumber(winRate)}%`}
          hint={`${formatNumber(lostStage?.count ?? 0)} صفقة خاسرة`}
          icon="chart"
          tone="violet"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <SectionCard
          title="قمع المبيعات"
          subtitle="عدد وقيمة الصفقات في كل مرحلة"
          className="lg:col-span-3"
          bodyClassName="p-4 lg:p-5"
        >
          <div className="space-y-3">
            {report.stageTotals.map((stage) => {
              const meta = stageMeta(stage.stage);
              const max = Math.max(...report.stageTotals.map((item) => item.value), 1);
              return (
                <div key={stage.stage} className="flex items-center gap-3">
                  <div className="w-20 shrink-0 text-[11.5px] font-medium text-slate-600">
                    {meta.label}
                  </div>
                  <div className="flex-1">
                    <div className="h-8 w-full overflow-hidden rounded-lg bg-slate-100">
                      <div
                        className={`flex h-full items-center justify-end rounded-lg px-2 text-[10px] font-semibold text-white ${meta.dot}`}
                        style={{ width: `${Math.max((stage.value / max) * 100, stage.value ? 12 : 2)}%` }}
                      >
                        {stage.count}
                      </div>
                    </div>
                  </div>
                  <div className="w-24 shrink-0 text-left text-[11px] font-semibold text-slate-700">
                    {formatCompactMoney(stage.value)}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 border-t border-slate-100 pt-3 text-center">
            <div>
              <p className="text-[10px] text-slate-400">أعلى قيمة</p>
              <p className="text-[12px] font-bold text-slate-800">
                {formatCompactMoney(Math.max(...report.stageTotals.map((stage) => stage.value)))}
              </p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400">متوسط الإغلاق</p>
              <p className="text-[12px] font-bold text-slate-800">
                {formatCompactMoney(wonStage?.count ? wonValue / wonStage.count : 0)}
              </p>
            </div>
            <div>
              <p className="text-[10px] text-slate-400">قيمة مفقودة</p>
              <p className="text-[12px] font-bold text-slate-800">
                {formatCompactMoney(lostStage?.value ?? 0)}
              </p>
            </div>
          </div>
        </SectionCard>

        <SectionCard
          title="الإيرادات الشهرية"
          subtitle="قيمة الصفقات المُنشأة في آخر 8 أشهر"
          className="lg:col-span-2"
          bodyClassName="p-4"
        >
          <div className="flex h-[190px] items-end justify-between gap-1.5">
            {report.monthly.map((month) => (
              <div key={month.label} className="group flex flex-1 flex-col items-center gap-1.5">
                <div className="flex h-full w-full items-end justify-center">
                  <div
                    className="w-full max-w-[26px] rounded-t-md bg-gradient-to-t from-slate-200 to-indigo-500 transition group-hover:from-indigo-200 group-hover:to-indigo-600"
                    style={{ height: `${Math.max((month.value / maxMonthly) * 100, 3)}%` }}
                    title={formatMoney(month.value)}
                  />
                </div>
                <span className="text-[9.5px] text-slate-400">{month.label}</span>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <SectionCard
          title="أداء فريق المبيعات"
          subtitle="القيمة الكلية مقابل المكسوب"
          bodyClassName="p-0"
        >
          <div className="overflow-x-auto">
            <table className="w-full min-w-[480px] border-collapse">
              <thead className="bg-slate-50/70">
                <tr>
                  <th className="th">المندوب</th>
                  <th className="th">الصفقات</th>
                  <th className="th">القيمة</th>
                  <th className="th">مكسوب</th>
                  <th className="th">الأداء</th>
                </tr>
              </thead>
              <tbody>
                {report.owners.map((owner) => (
                  <tr key={owner.owner} className="border-t border-slate-100">
                    <td className="td text-[12.5px] font-semibold text-slate-800">{owner.owner}</td>
                    <td className="td text-[12px]">{formatNumber(owner.count)}</td>
                    <td className="td text-[12px]">{formatCompactMoney(owner.total)}</td>
                    <td className="td text-[12px] font-semibold text-emerald-700">
                      {formatCompactMoney(owner.won)}
                    </td>
                    <td className="td">
                      <ProgressBar
                        value={(owner.total / maxOwner) * 100}
                        height="h-1.5"
                        className="bg-indigo-500"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </SectionCard>

        <SectionCard title="مصادر العملاء" subtitle="من أين تأتي أفضل الفرص؟" bodyClassName="p-4">
          <ul className="space-y-3">
            {report.sources.map((source) => (
              <li key={source.source ?? "غير محدد"}>
                <div className="mb-1 flex items-center justify-between text-[11.5px]">
                  <span className="text-slate-600">{source.source ?? "غير محدد"}</span>
                  <span className="font-semibold text-slate-800">
                    {formatCompactMoney(source.total)} · {formatNumber(source.count)}
                  </span>
                </div>
                <ProgressBar
                  value={(source.total / maxSource) * 100}
                  height="h-1.5"
                  className="bg-violet-500"
                />
              </li>
            ))}
          </ul>
        </SectionCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SectionCard title="حالات العملاء" className="lg:col-span-1" bodyClassName="p-4">
          <ul className="space-y-2.5">
            {CONTACT_STATUSES.map((status) => {
              const count =
                report.contactsByStatus.find((row) => row.status === status.key)?.count ?? 0;
              return (
                <li key={status.key} className="flex items-center gap-2 text-[12px]">
                  <span className={`h-2 w-2 rounded-full ${status.dot}`} />
                  <span className="flex-1 text-slate-600">{status.label}</span>
                  <span className="font-semibold text-slate-800">{formatNumber(count)}</span>
                  <span className="w-10 text-left text-[10px] text-slate-400">
                    {Math.round((count / statusTotal) * 100)}%
                  </span>
                </li>
              );
            })}
          </ul>
        </SectionCard>

        <SectionCard
          title="ملخص تنفيذي"
          className="lg:col-span-2"
          bodyClassName="p-4 lg:p-5"
        >
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5">
              <p className="text-[11px] font-semibold text-slate-500">أفضل مندوب</p>
              <p className="mt-1 text-[13px] font-bold text-slate-900">
                {report.owners[0]?.owner ?? "—"}
              </p>
              <p className="text-[11px] text-slate-500">
                {formatCompactMoney(report.owners[0]?.won ?? 0)} مبيعات مُغلقة
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5">
              <p className="text-[11px] font-semibold text-slate-500">أفضل مصدر</p>
              <p className="mt-1 text-[13px] font-bold text-slate-900">
                {report.sources[0]?.source ?? "—"}
              </p>
              <p className="text-[11px] text-slate-500">
                {formatNumber(report.sources[0]?.count ?? 0)} صفقة بقيمة{" "}
                {formatCompactMoney(report.sources[0]?.total ?? 0)}
              </p>
            </div>
          </div>
          <div className="mt-3 rounded-xl bg-indigo-50 p-3.5">
            <p className="flex items-center gap-1.5 text-[11.5px] font-semibold text-indigo-800">
              <Icon name="sparkle" className="h-3.5 w-3.5" />
              توصية
            </p>
            <p className="mt-1 text-[11.5px] leading-6 text-indigo-900/80">
              {winRate >= 50
                ? "نسبة الإغلاق جيدة — ركّز على زيادة عدد الفرص في مرحلة التأهيل لرفع قيمة خط الأنابيب."
                : "نسبة الإغلاق تحتاج تحسيناً — راجع أسباب الخسارة وحدّث معايير تأهيل الفرص قبل إرسال العروض."}{" "}
              أكبر مرحلة من حيث القيمة هي{" "}
              <span className="font-semibold">
                {stageMeta(
                  [...report.stageTotals].sort((a, b) => b.value - a.value)[0].stage,
                ).label}
              </span>
              .
            </p>
          </div>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {DEAL_STAGES.map((stage) => {
              const item = report.stageTotals.find((row) => row.stage === stage.key);
              return (
                <span key={stage.key} className={`chip ${stage.soft}`}>
                  <span className={`h-1.5 w-1.5 rounded-full ${stage.dot}`} />
                  {stage.label}: {formatNumber(item?.count ?? 0)}
                </span>
              );
            })}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}
