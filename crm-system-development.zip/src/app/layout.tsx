import type { Metadata } from "next";
import type { ReactNode } from "react";
import { AppShell } from "@/components/AppShell";
import "./globals.css";

export const metadata: Metadata = {
  title: "مَدار CRM · إدارة علاقات العملاء",
  description:
    "نظام إدارة علاقات العملاء: عملاء، شركات، خط صفقات، مهام، وتقارير أداء المبيعات.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className="bg-[#f5f6fb] text-slate-900 antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
