import { deleteCompany } from "@/app/actions";
import { CompanyFormModal } from "@/components/forms";
import { FilterBar } from "@/components/Filters";
import { Icon } from "@/components/icons";
import { DeleteButton } from "@/components/Interactive";
import { EmptyState, PageHeader, ProgressBar } from "@/components/ui";
import { formatCompactMoney, formatNumber } from "@/lib/format";
import { getCompanies } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export default async function CompaniesPage({
  searchParams,
}: {
  searchParams: Promise<{ search?: string }>;
}) {
  await ensureSeed();
  const params = await searchParams;
  const companies = await getCompanies({ search: params.search });

  const totalPipeline = companies.reduce((sum, company) => sum + company.pipeline, 0);
  const totalContacts = companies.reduce((sum, company) => sum + company.contactCount, 0);
  const maxPipeline = Math.max(...companies.map((company) => company.pipeline), 1);

  return (
    <div>
      <PageHeader
        title="الشركات"
        description="الحسابات التي تتعامل معها، مع حجم الفرص وعدد جهات الاتصال في كل حساب."
      >
        <CompanyFormModal triggerLabel="شركة جديدة" />
      </PageHeader>

      <div className="mb-5 grid grid-cols-3 gap-3">
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">عدد الشركات</p>
          <p className="mt-1 text-xl font-bold text-slate-900">{formatNumber(companies.length)}</p>
        </div>
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">قيمة الفرص المفتوحة</p>
          <p className="mt-1 text-xl font-bold text-indigo-700">
            {formatCompactMoney(totalPipeline)}
          </p>
        </div>
        <div className="card p-4">
          <p className="text-[11px] text-slate-500">جهات الاتصال</p>
          <p className="mt-1 text-xl font-bold text-slate-900">{formatNumber(totalContacts)}</p>
        </div>
      </div>

      <FilterBar
        basePath="/companies"
        placeholder="ابحث باسم الشركة أو القطاع أو المدينة…"
        searchValue={params.search ?? ""}
      />

      {companies.length ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {companies.map((company) => (
            <article key={company.id} className="card group flex flex-col p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-slate-800 to-slate-600 text-[13px] font-bold text-white">
                  {company.name.slice(0, 2)}
                </span>
                <div className="min-w-0 flex-1">
                  <h2 className="truncate text-[14px] font-semibold text-slate-900">
                    {company.name}
                  </h2>
                  <p className="truncate text-[11.5px] text-slate-400">
                    {company.industry ?? "قطاع غير محدد"}
                    {company.city ? ` · ${company.city}` : ""}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <CompanyFormModal
                    initial={company}
                    triggerLabel=""
                    triggerIcon="edit"
                    triggerClass="rounded-md p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
                  />
                  <DeleteButton
                    id={company.id}
                    action={deleteCompany}
                    confirmText="حذف الشركة سيُبقي العملاء لكن يفصل ارتباطهم. متابعة؟"
                    className="rounded-md p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                  />
                </div>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2">
                <div className="rounded-xl bg-slate-50 p-2.5">
                  <p className="text-[10px] text-slate-400">جهات الاتصال</p>
                  <p className="text-[13px] font-bold text-slate-800">
                    {formatNumber(company.contactCount)}
                  </p>
                </div>
                <div className="rounded-xl bg-indigo-50/70 p-2.5">
                  <p className="text-[10px] text-indigo-500">صفقات مفتوحة</p>
                  <p className="text-[13px] font-bold text-indigo-800">
                    {formatNumber(company.openDealCount)}
                  </p>
                </div>
              </div>

              <div className="mt-3">
                <div className="mb-1 flex items-center justify-between text-[10.5px]">
                  <span className="text-slate-400">قيمة الفرص</span>
                  <span className="font-semibold text-slate-700">
                    {formatCompactMoney(company.pipeline)}
                  </span>
                </div>
                <ProgressBar value={(company.pipeline / maxPipeline) * 100} height="h-1.5" />
              </div>

              <div className="mt-3 space-y-1.5 border-t border-slate-100 pt-3 text-[11.5px] text-slate-500">
                {company.website && (
                  <p className="flex items-center gap-1.5" dir="ltr">
                    <Icon name="external" className="h-3.5 w-3.5 text-slate-400" />
                    <span className="truncate">{company.website}</span>
                  </p>
                )}
                {company.phone && (
                  <p className="flex items-center gap-1.5" dir="ltr">
                    <Icon name="phone" className="h-3.5 w-3.5 text-slate-400" />
                    {company.phone}
                  </p>
                )}
                {company.employees && (
                  <p className="flex items-center gap-1.5">
                    <Icon name="users" className="h-3.5 w-3.5 text-slate-400" />
                    {formatNumber(company.employees)} موظف
                  </p>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState
          icon="building"
          title="لا توجد شركات مطابقة"
          description="أضف شركة جديدة لربط العملاء والصفقات بها."
        />
      )}
    </div>
  );
}
