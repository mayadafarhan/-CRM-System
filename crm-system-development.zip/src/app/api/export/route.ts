import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, contacts, deals } from "@/db/schema";
import { stageMeta, contactStatusMeta } from "@/lib/format";

export const dynamic = "force-dynamic";

function escapeCsv(value: string | number | null | undefined) {
  const text = value == null ? "" : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

export async function GET() {
  const rows = await db
    .select({
      id: deals.id,
      title: deals.title,
      company: companies.name,
      contact: contacts.name,
      stage: deals.stage,
      value: deals.value,
      currency: deals.currency,
      probability: deals.probability,
      owner: deals.owner,
      source: deals.source,
      expectedCloseDate: deals.expectedCloseDate,
      status: contacts.status,
    })
    .from(deals)
    .leftJoin(companies, eq(deals.companyId, companies.id))
    .leftJoin(contacts, eq(deals.contactId, contacts.id))
    .orderBy(desc(deals.value));

  const header = [
    "المعرّف",
    "الصفقة",
    "الشركة",
    "جهة الاتصال",
    "حالة العميل",
    "المرحلة",
    "القيمة",
    "العملة",
    "الاحتمالية",
    "المسؤول",
    "المصدر",
    "تاريخ الإغلاق المتوقع",
  ];

  const lines = [
    header.map(escapeCsv).join(","),
    ...rows.map((row) =>
      [
        row.id,
        row.title,
        row.company ?? "",
        row.contact ?? "",
        row.status ? contactStatusMeta(row.status).label : "",
        stageMeta(row.stage).label,
        Number(row.value),
        row.currency,
        `${row.probability}%`,
        row.owner,
        row.source ?? "",
        row.expectedCloseDate ?? "",
      ]
        .map(escapeCsv)
        .join(","),
    ),
  ];

  return new Response(`\uFEFF${lines.join("\n")}`, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="madar-deals.csv"',
    },
  });
}
